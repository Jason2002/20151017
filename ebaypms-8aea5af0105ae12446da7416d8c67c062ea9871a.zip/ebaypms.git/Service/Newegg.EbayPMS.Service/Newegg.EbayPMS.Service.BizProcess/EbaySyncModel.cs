﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using eBay.Service.Call;
using eBay.Service.Core.Soap;
using Newegg.EbayPMS.Service.Common;
using Newegg.EbayPMS.Service.DataAccess;
using Newegg.EbayPMS.Service.DataAccess.Interface;
using Newegg.EbayPMS.Service.DTO;

namespace Newegg.EbayPMS.Service.BizProcess
{
    public static class EbaySyncModel
    {
        [ThreadStatic]
        private static ITrackingApiLog m_Logger;

        public static ITrackingApiLog Logger
        {
            get
            {
                if (m_Logger == null)
                {
                    m_Logger = new TrackingApiLog();
                }
                return m_Logger;
            }
            set { m_Logger = value; }
        }

        private static List<EbayItemDTO> GetItems()
        {
            List<EbayItemDTO> list = new List<EbayItemDTO>();
            var allItems = EbayCallModel.GetSellerList();
            foreach (var item in allItems)
            {
                list.Add(BuildWebItem(item));
            }
            Logger.Close();
            return list;
        }

        public static EbayItemDTO GetItem(string ebayCode)
        {
            EbayItemDTO webItem = null;
            var item = EbayCallModel.GetItem(ebayCode);
            if (item != null)
            {
                webItem= BuildWebItem(item);
            }
            Logger.Close();
            if (webItem != null)
            {
                UpdateDb(webItem);
            }
            return webItem;
        }

        public static void SyncAllItem()
        {
            var items = GetItems();
            if (!items.IsNullOrEmpty())
            {
                foreach (var item in items.OrderBy(item => item.StartListDate.GetValueOrDefault()))
                {
                    UpdateDb(item);
                }
            }
        }

        private static EbayItemDTO BuildWebItem(ItemType item)
        {
            EbayItemDTO webdto = new EbayItemDTO();
            webdto.EbayCode = item.ItemID;
            webdto.EbayTitle = item.Title;
            webdto.SKU = item.SKU;
            if (item.ListingTypeSpecified)
            {
                if (item.StartPrice != null
                    && item.ListingType != ListingTypeCodeType.FixedPriceItem)
                {
                    webdto.StartingPrice = (decimal?) item.StartPrice.Value;
                }
                if (item.ListingType == ListingTypeCodeType.FixedPriceItem
                    && item.SellingStatus != null
                    && item.SellingStatus.CurrentPrice != null)
                {
                    webdto.FixedPrice = (decimal?) item.SellingStatus.CurrentPrice.Value;
                }
                else if (item.BuyItNowPrice != null
                         && item.BuyItNowPrice.Value > 0
                         && item.SellingStatus != null
                         && item.SellingStatus.BidCount > 0)
                {
                    webdto.FixedPrice = (decimal?) item.BuyItNowPrice.Value;
                }
            }
            if (item.SellingStatus != null)
            {
                webdto.ListingStatus = item.SellingStatus.ListingStatus.ToString();
            }
            if (item.ListingDetails != null)
            {
                if (item.ListingDetails.StartTimeSpecified)
                {
                    webdto.StartListDate = item.ListingDetails.StartTime;
                }
                if (item.ListingDetails.EndTimeSpecified)
                {
                    webdto.EndListDate = item.ListingDetails.EndTime;
                }
                if (!item.ListingDetails.RelistedItemID.IsNullOrEmpty())
                {
                    webdto.RelistedItemID = item.ListingDetails.RelistedItemID;
                }
            }
            //webdto.SerialNumber = ParseSNFromSKU(webdto.SKU);
            DateTime startedTime = webdto.StartListDate.HasValue 
                ? webdto.StartListDate.Value 
                : DateTime.Now.AddDays(-29);
            var orderTran =
                 EbayCallModel.GetItemTransactions(item.ItemID, startedTime);
            if (orderTran != null)
            {
                webdto.IsSold = true;
                BuildSellInfo(orderTran, webdto);
            }

            if (webdto.ListingStatus.AreEqualsTo(ListingStatusCodeType.Completed.ToString())
                && !webdto.IsSold.GetValueOrDefault())
            {
                webdto.Status = ItemStatus.Ended;
            }
            webdto.Status = webdto.GetStatus();

            //File.AppendAllText("WebItem.txt", Environment.NewLine + SerializeHelper.XmlSerializer(webdto));
            return webdto;
        }

        //private static string ParseSNFromSKU(string sku)
        //{
        //    if (sku.IsNullOrEmpty())
        //    {
        //        return string.Empty;
        //    }
        //    string [] strs = sku.SplitEx(' ');
        //    if (!strs.IsNullOrEmpty())
        //    {
        //        foreach (var str in strs)
        //        {
        //            if (!str.IsNullOrEmpty())
        //            {
        //                string field = str.ToUpperEx().ToUpper();
        //                if (field.Contains("FFD")
        //                    || field.Contains("EBAY-A"))
        //                {
        //                    return field;
        //                }
        //            }
        //        }
        //        if (strs.Length == 5)
        //        {
        //            return strs[3];
        //        }
        //    }
        //    return string.Empty;
        //}

        private static void BuildSellInfo(TransactionType orderTran, EbayItemDTO webdto)
        {
            decimal tax = 0.0m;
            if (orderTran.ShippingDetails != null)
            {
                if(orderTran.ShippingDetails.SalesTax != null
                    && orderTran.ShippingDetails.SalesTax.SalesTaxAmount != null)
                {
                    tax = (decimal) orderTran.ShippingDetails.SalesTax.SalesTaxAmount.Value;
                }
                if (orderTran.ShippingDetails.ShipmentTrackingDetails!=null
                    && orderTran.ShippingDetails.ShipmentTrackingDetails.Count>0)
                {
                    webdto.TrackingNumber = orderTran.ShippingDetails.ShipmentTrackingDetails[0].ShipmentTrackingNumber;
                }
            }
            webdto.TotalPrice = (decimal) orderTran.TransactionPrice.Value + tax;
            if (orderTran.ShippingServiceSelected != null)
            {
                webdto.ShippingMethod = orderTran.ShippingServiceSelected.ShippingService;
                if (orderTran.ShippingServiceSelected.ShippingServiceCost != null)
                {
                    webdto.ShippingFee = (decimal?) orderTran.ShippingServiceSelected.ShippingServiceCost.Value;
                }
            }
            if (orderTran.PaidTimeSpecified)
            {
                webdto.PaidDate = orderTran.PaidTime;
            }
            if (orderTran.ShippedTimeSpecified)
            {
                webdto.ShippedDate = orderTran.ShippedTime;
                if (webdto.ShippingMethod.AreEqualsTo("Pickup"))
                {
                    webdto.ReceiveDate = webdto.ShippedDate;
                }
            }
        }

        private static EbayItemDTO UpdateDb(EbayItemDTO webItem)
        {
            webItem.LastEditDate = DateTimeHelper.GetDateTime();
            webItem.LastEditUser = "sys";
            webItem.LastEditUserName = "sys";

            var dbWebItem = DaoFactory.GetDao<IEbayItemDao>().GetEbayDetail(webItem.EbayCode);
            if (dbWebItem == null)
            {
                webItem.InDate = DateTimeHelper.GetDateTime();
                webItem.InUser = "sys";
                webItem.InUserName = "sys";
                DaoFactory.GetDao<IEbayItemDao>().InsertEbayDetail(webItem);
            }
            else
            {
                webItem.ControlCode = dbWebItem.ControlCode;
                webItem.InDate = dbWebItem.InDate;
                webItem.InUser = dbWebItem.InUser;
                webItem.InUserName = dbWebItem.InUserName;
                DaoFactory.GetDao<IEbayItemDao>().UpdateEbayDetail(webItem);
            }

            var dbItems = DaoFactory.GetDao<IEbayItemDao>().GetItemByEbayCode(webItem.EbayCode);
            if (!dbItems .IsNullOrEmpty())
            {
                for (int index = 0; index < dbItems.Count; index++)
                {
                    EbayItemDTO dbitem = dbItems[index];
                    if (!webItem.RelistedItemID.IsNullOrEmpty())
                    {
                        dbitem.EbayCode = webItem.RelistedItemID;
                        dbitem.LastEditUser = "sys";
                        dbitem.LastEditUserName = "sys";
                        dbitem = EbayModel.SaveEbayCode(dbitem,false, false);
                    }
                    else
                    {
                        RefreshItemStatus(webItem, dbitem);
                    }
                    if (dbWebItem == null
                        && webItem.ControlCode.IsNullOrEmpty())
                    {
                        webItem.ControlCode = dbitem.ControlCode;
                        DaoFactory.GetDao<IEbayItemDao>().UpdateEbayDetail(webItem);
                    }
                }
            }





            return null;
        }

        public static void RefreshItemStatus(EbayItemDTO webItem, EbayItemDTO dbitem)
        {
            bool needToUpdate = false;
            if (dbitem.Status.IsIn(ItemStatus.Listed, ItemStatus.Ended,ItemStatus.Paid,ItemStatus.Shipped,ItemStatus.Ready)
                && webItem.ReceiveDate.HasValue)
            {
                needToUpdate = true;
                dbitem.Status = ItemStatus.Received;
            }
            else if (dbitem.Status.IsIn(ItemStatus.Listed, ItemStatus.Ended, ItemStatus.Paid, ItemStatus.Ready)
                && webItem.ShippedDate.HasValue)
            {
                needToUpdate = true;
                dbitem.Status = ItemStatus.Shipped;
            }
            else if (dbitem.Status.IsIn(ItemStatus.Listed, ItemStatus.Ended, ItemStatus.Ready)
                && webItem.PaidDate.HasValue)
            {
                dbitem.Status = ItemStatus.Paid;
                needToUpdate = true;
            }

            if (dbitem.Status.IsIn(ItemStatus.Listed,ItemStatus.Ready)
                && webItem.GetStatus().AreEqualsTo(ItemStatus.Ended))
            {
                needToUpdate = true;
                dbitem.Status = ItemStatus.Ended;
            }
            if (needToUpdate)
            {
                dbitem.LastEditUser = "sys";
                dbitem.LastEditUserName = "sys";
                dbitem.LastEditDate = DateTimeHelper.GetDateTime();
                DaoFactory.GetDao<IEbayItemDao>().UpdateItem(dbitem);
            }
        }
    }
}
