﻿
using System;
using System.Collections.Generic;
using Newegg.EbayPMS.Service.Common;
using Newegg.Oversea.Framework.Utilities.Encryption;
using Org.Apache.Zookeeper.Data;


namespace Newegg.EbayPMS.Service.BizProcess
{

    public static class EbaySettingProvider
    {
        [ThreadStatic]
        private static EbayApiSetting s_setting;

        public static EbayApiSetting GetEbaySetting()
        {
            if (s_setting == null)
            {
                s_setting = GetEbaySettingFromApi();
            }
            return s_setting;
        }

        private static EbayApiSetting GetEbaySettingFromApi()
        {
            EbayApiSetting setting = null;
            try
            {
                using (var client = EggKeeper.Sdk.EggKeeperFactory.GetEggKeeper())
                {
                    var settingStr = client.GetData<String>(ConfigHelper.EbayConfigSysName, "EbayApiSetting");
                    setting = SerializeHelper.JsonDeserialize<EbayApiSetting>(settingStr);

                    if (setting != null
                        && !setting.ProxyUserPassword.IsNullOrEmpty())
                    {
                        setting.ProxyUserPassword = EncryptionHelper.Decrypt(EncryptionAlgorithm.Rijndael, setting.ProxyUserPassword);
                    }

                }
            }
            catch (Exception ex)
            {
                LogApiHelper.WriteException(ex);
                throw ex;
            }
            return setting;
        }
    }

    public class EbayApiSetting
    {
        public string EbayApiURL { get; set; }
        public string ProxyURL { get; set; }
        public string ProxyUserID { get; set; }
        public string ProxyUserPassword { get; set; }
        public string EbayToken { get; set; }
        public string EbayApplication { get; set; }
        public string EbayDeveloper { get; set; }
        public string EbayCertificate { get; set; }
    }
}
