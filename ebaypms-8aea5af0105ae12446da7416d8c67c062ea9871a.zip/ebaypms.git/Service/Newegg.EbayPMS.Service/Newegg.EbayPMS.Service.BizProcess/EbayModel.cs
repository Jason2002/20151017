﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Newegg.ABS.CMS.Service.DTO;
using Newegg.EbayPMS.Service.Common;
using Newegg.EbayPMS.Service.DataAccess;
using Newegg.EbayPMS.Service.DataAccess.Interface;
using Newegg.EbayPMS.Service.DTO;


namespace Newegg.EbayPMS.Service.BizProcess
{
    public class EbayModel
    {
        public static List<EbayItemDTO> QueryItems(EbayItemReqDTO req)
        {
            string whereSql = BuildWhereSql(req);
            return DaoFactory.GetDao<IEbayItemDao>().QueryItem(whereSql, req);
        }

        private static string BuildWhereSql(EbayItemReqDTO req)
        {
            StringBuilder sqlBuilder = new StringBuilder(1024);
            if (!req.ControlCode.IsNullOrEmpty())
            {
                sqlBuilder.AppendLine(" AND A.ControlCode = @ControlCode");
            }
            if (!req.ItemCode.IsNullOrEmpty())
            {
                sqlBuilder.AppendLine(" AND A.ItemCode=@ItemCode");
            }
            if (!req.Category.IsNullOrEmpty())
            {
                sqlBuilder.AppendLine(" AND A.[Category]=@Category");
            }
            if (req.FromDate.HasValue)
            {
                sqlBuilder.AppendLine(" AND A.SubmitDate >= @FromDate");
            }
            if (req.ToDate.HasValue)
            {
                sqlBuilder.AppendLine(" AND A.SubmitDate <@ToDate");
            }
            if (!req.SerialNumber.IsNullOrEmpty())
            {
                sqlBuilder.AppendLine(" and a.SerialNumber=@SerialNumber ");
            }
            if (!req.Status.IsNullOrEmpty())
            {
                sqlBuilder.AppendLine(" AND A.Status=@Status");
            }
            if (!req.TrackingNumber.IsNullOrEmpty())
            {
                sqlBuilder.AppendLine(" AND B.TrackingNumber=@TrackingNumber");
            }
            if (!req.InUserName.IsNullOrEmpty())
            {
                sqlBuilder.AppendLine(string.Format(" and (A.InUser=@InUserName OR InUserName like '%{0}%')"
                    , StringHelper.MakeSafeSql(req.InUserName)));
            }
            if (!req.EbayTitle.IsNullOrEmpty())
            {
                sqlBuilder.AppendLine(string.Format(" AND B.EbayTitle LIKE '%{0}%' ",
                    StringHelper.MakeSafeSql(req.EbayTitle)));
            }

            if (!req.EbayCode.IsNullOrEmpty())
            {
                sqlBuilder.AppendLine(" AND A.ebayCode=@EbayCode");
            }

            //if (sqlBuilder.Length > 0)
            //{
            //    sqlBuilder.Insert(0, "where 1=1 ");
            //}
            return sqlBuilder.ToString();
        }

        public static EbayItemDTO GetItem(string controlCode
            ,bool withPicture=false
            ,bool withOption=false
            ,bool allowNull=false)
        {
            var dbItem=DaoFactory.GetDao<IEbayItemDao>().GetItem(controlCode);
            if (dbItem == null
                && !allowNull)
            {
                throw new BizException("Cannot find item [{0}].",controlCode);
            }
            if (withPicture)
            {
                dbItem.PictureList = DaoFactory.GetDao<IItemAttachmentDao>()
                    .GetAttachments(dbItem.ControlCode, AttachmentDTO.OrderType_ControlCode);
            }
            if (withOption)
            {
                dbItem.ItemOptionList = DaoFactory.GetDao<IEbayItemDao>()
                    .GetItemDetail(controlCode);
            }

            return dbItem;
        }

        public static EbayItemDTO SaveEbayCode(EbayItemDTO request,bool syncEbayCode=true,bool returnAll=true)
        {
            request.ControlCode.AssertIsNotEmpty("ControlCode");
            request.LastEditUser.AssertIsNotEmpty("LastEditUser");
            var dbItem = GetItem(request.ControlCode);
            if (!dbItem.EbayCode.IsNullOrEmpty()
                && request.EbayCode.IsNullOrEmpty())
            {
                throw new BizException("Cannot clear ebayID.");
            }

            if (dbItem.Status.IsIn(ItemStatus.Paid,ItemStatus.Shipped,ItemStatus.Received))
            {
                throw new BizException("Item has been {0}.",dbItem.Status);
            }

            if (!request.EbayCode.AreEqualsTo(dbItem.EbayCode))
            {
                dbItem.EbayCode = request.EbayCode.Trim();
                dbItem.LastEditUser = request.LastEditUser;
                dbItem.LastEditUserName = request.LastEditUserName;
                dbItem.LastEditDate = DateTimeHelper.GetDateTime();
                dbItem.ListedTimes = dbItem.ListedTimes.GetValueOrDefault() + 1;
                var ebaydetail = GetEbayDetail(dbItem.EbayCode) ;
                if (ebaydetail == null
                    && syncEbayCode)
                {
                    try
                    {
                        ebaydetail = SyncEbayWebItem(dbItem);
                    }
                    catch (Exception ex)
                    {
                        LogApiHelper.WriteException(ex);
                        ebaydetail = null;
                    }
                }
                if (ebaydetail != null)
                {
                    dbItem.Status = ebaydetail.GetStatus();
                    ebaydetail.ControlCode = dbItem.ControlCode;
                    DaoFactory.GetDao<IEbayItemDao>().UpdateEbayDetail(ebaydetail);
                }
                else
                {
                    dbItem.Status = ItemStatus.Listed;
                }
                DaoFactory.GetDao<IEbayItemDao>().UpdateItem(dbItem);
            }
            if (returnAll)
            {
                return GetItem(dbItem.ControlCode, true, true);
            }
            return dbItem;
        }

        private static EbayItemDTO SyncEbayWebItem(EbayItemDTO dbItem)
        {
            dbItem.EbayCode.AssertIsNotEmpty("ebayCode");
            return EbaySyncModel.GetItem(dbItem.EbayCode);
        }

        public static EbayItemDTO GetEbayDetail(string ebayCode)
        {
            return DaoFactory.GetDao<IEbayItemDao>().GetEbayDetail(ebayCode);
        }

        public static ItemConfigResDTO GetConfig()
        {
            var config = new ItemConfigResDTO();
            config.CategoryList = GetCategoryList();
            config.StatusList = new List<string>()
            {
                ItemStatus.Ready,
                ItemStatus.Listed,
                ItemStatus.Paid,
                ItemStatus.Shipped,
                ItemStatus.Received,
                ItemStatus.Ended
            };
            return config;
        }

        private static List<string> GetCategoryList()
        {
            var list = DaoFactory.GetDao<IEbayItemDao>().GetCategoryList();
            if (!list.IsNullOrEmpty())
            {
                return list.Select(item => item.Category).ToList();
            }
            return new List<string>();
        }

        public static EbayItemDTO CheckEbayCode(EbayItemDTO item)
        {
            item.EbayCode.AssertIsNotEmpty("EbayCode");
            var ebaydetail = GetEbayDetail(item.EbayCode);
            if (ebaydetail == null)
            {
                ebaydetail = SyncEbayWebItem(item);
            }

            if (ebaydetail != null)
            {
                ebaydetail.Status = ebaydetail.GetStatus();
            }

            return ebaydetail;
        }


        private static EbayItemDTO GetItemByEbayItem(string ebayCode)
        {
            var list=QueryItems(new EbayItemReqDTO() {EbayCode = ebayCode});
            if (list.IsNullOrEmpty())
            {
                return null;
            }
            return list[0];
        }

    }
}
