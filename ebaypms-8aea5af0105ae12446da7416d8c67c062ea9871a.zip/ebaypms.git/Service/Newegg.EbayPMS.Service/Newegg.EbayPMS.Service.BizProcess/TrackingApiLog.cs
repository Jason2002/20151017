﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using eBay.Service.Util;
using Newegg.EbayPMS.Service.Common;

namespace Newegg.EbayPMS.Service.BizProcess
{

    public interface ITrackingApiLog
    {
        void Write(string msg, params object[] strs);
        void WriteException(Exception ex);
        void Close();
    }
    
    class TrackingApiLog : ITrackingApiLog
    {
        private const int MaxQueue = 512*1024;

        readonly StringBuilder m_msgBuilder = new StringBuilder();

        public void Write(string msg,params object[] strs)
        {
            m_msgBuilder.AppendFormat("{0}    ", DateTime.Now);
            if (strs.IsNullOrEmpty())
            {
                m_msgBuilder.AppendLine(msg);
            }
            else
            {
                m_msgBuilder.AppendFormat(msg,strs);
                m_msgBuilder.AppendLine();
            }
            if (m_msgBuilder.Length > MaxQueue)
            {
                Close();
            }
        }

        public void WriteException(Exception ex)
        {
            LogApiHelper.WriteException(ex);
            Write(ExceptionHandler.GetExceptionMessage(ex));
           
        }

        public void Close()
        {
            if (m_msgBuilder.Length > 0)
            {
                LogApiHelper.WriteInformation(m_msgBuilder.ToString());
                m_msgBuilder.Clear();
            }
        }
    }
}
