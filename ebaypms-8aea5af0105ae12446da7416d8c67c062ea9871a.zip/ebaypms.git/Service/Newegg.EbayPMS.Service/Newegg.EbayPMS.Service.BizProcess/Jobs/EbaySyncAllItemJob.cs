﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using Newegg.EbayPMS.Service.Common;
using Newegg.Oversea.Framework.JobConsole.Client;

namespace Newegg.EbayPMS.Service.BizProcess
{
    public class EbaySyncAllItemJob:IJobAction
    {
        public void Run(JobContext context)
        {
            EbaySyncModel.SyncAllItem();
        }
    }
}
