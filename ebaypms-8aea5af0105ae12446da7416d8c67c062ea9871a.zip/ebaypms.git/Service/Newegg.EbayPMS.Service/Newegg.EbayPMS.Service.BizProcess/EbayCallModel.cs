﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using eBay.Service.Call;
using eBay.Service.Core.Sdk;
using eBay.Service.Core.Soap;
using eBay.Service.Util;
using Newegg.EbayPMS.Service.Common;


namespace Newegg.EbayPMS.Service.BizProcess
{
    static class EbayCallModel
    {
        
        private static ApiContext GetApiContext()
        {
            EbayApiSetting setting = EbaySettingProvider.GetEbaySetting();
            var apiContext = new ApiContext();
            apiContext.SoapApiServerUrl = setting.EbayApiURL;
            apiContext.WebProxy = new WebProxy(setting.ProxyURL, true);
            ApiCredential apiCredential = new ApiCredential();
            apiCredential.eBayToken = setting.EbayToken;

                //"AgAAAA**AQAAAA**aAAAAA**TyFtUw**nY+sHZ2PrBmdj6wVnY+sEZ2PrA2dj6wAloOjAJaEogidj6x9nY+seQ**rcMAAA**AAMAAA**UGqbRo1t8HNjlKSOuoxRI5OLA3N45hc9qine8NJg44olS5y6Ku9MPV9IIcEx5qOcQ2mcNyU9474rvR3TY3i3HYwjobYm1TQoEcH+3ohH2iu+lsuijkpcRMvPGM6Wizbxc+1sSHnWlQ/0lH66YhKAivizowsu+bUCSOF+R/tikKIV1CprCJiTkYOLg9Oyj0N82cNDVnbgQj4DyXQlCcyCgZlwMvfS3lr3k3ctDD3SCfnr3YzFywgdsItPVDghvx40aYDj1Y8ScUYy2aypvRyAd8wdkWRcqmSJVad3GQgORZktAGbzSBWEZLsVQ73VBrNRw4+jj7iKlVcgRvxO2wY0It0K3uyDFZZ3SGUqC17jdrYZtiN534RyBxO7OKlDSaVNUix7qTFX5d6KMkuptAhY4kbCeNB74PiHS19hmIK7nFA92vtY8KBd97xm80PYDy+DQiNrbqsbCXuRSNuWGXVv+ccLng1/x6wXU8NSJanmCqabeDq0qk0CcaI3DbUYTUhoT18EkJ6cM/aWYac4Kk4waJksGkITyCh65zooj35/tYmLF/r4Zme5Tb8ouiyF6wDn1pzFCbXzG6UQrh8GgDxVZ+gHHVwOgLKXXVGW172uywsWFs0hPrrrRZzkRilO0k/2q1HDx9aZt4SqHlSxGFSSeLkBp6MndJqi6bqXU8kTdG+nEqpDNl9e+KCaPQxjJKfaDyZqzBktOZ7YYr/RXfS0FlzczbTJ6VuioxP4tv7vN6T4+lp7L7ZxTbbq5OfgWx5C";




            apiContext.ApiCredential = apiCredential;
            apiContext.ApiCredential.ApiAccount.Application = setting.EbayApplication;// "Newegg220-8100-44f5-af8e-f85573df2ee";
            apiContext.ApiCredential.ApiAccount.Developer = setting.EbayDeveloper;// "97af9cca-5ed5-4678-9bf7-e6e37319e776";
            apiContext.ApiCredential.ApiAccount.Certificate = setting.EbayCertificate;// "e651243a-383c-4fdf-b182-7c219ab710ae";
            //apiContext.ApiLogManager = new ApiLogManager(new ApiLoggerCollection() { new EbaySyncModel.NEApiLogger() });
            apiContext.Site = SiteCodeType.US;
            apiContext.WebProxy.Credentials = new NetworkCredential(setting.ProxyUserID,setting.ProxyUserPassword);
            return apiContext;
        }

        public static List<ItemType> GetSellerList(int pageNumber = 1)
        {
            var list = new List<ItemType>();

            var call = new GetSellerListCall
            {
                ApiContext = GetApiContext(),
                DetailLevelList = new DetailLevelCodeTypeCollection() {DetailLevelCodeType.ReturnAll},
                Version = "939",
                Pagination = new PaginationType()
                {
                    EntriesPerPage = 20,
                    EntriesPerPageSpecified = true,
                    PageNumber = pageNumber,
                    PageNumberSpecified = true
                },
                StartTimeFrom = DateTime.Now.AddMonths(-2),
                StartTimeTo = DateTime.Now
            };
            try
            {
                EbaySyncModel.Logger.Write("GetSellerList for page:{0} ",pageNumber);
                list.AddRange(call.GetSellerList().ToArray());
                if (call.PaginationResult != null
                    && pageNumber < call.PaginationResult.TotalNumberOfPages)
                {
                    pageNumber++;
                    list.AddRange(GetSellerList(pageNumber));
                }
                return list;
            }
            catch (Exception ex)
            {
                EbaySyncModel.Logger.WriteException(ex);
                LogApiHelper.WriteException(ex);
                return list;
            }
        }

        public static ItemType GetItem(string ebayCode)
        {
            GetItemCall call = new GetItemCall
            {
                DetailLevelList = new DetailLevelCodeTypeCollection() {DetailLevelCodeType.ReturnAll},
                ApiContext = GetApiContext()
            };
            try
            {
                EbaySyncModel.Logger.Write("GetItem for ebayCode:{0} ", ebayCode);
                var item=call.GetItem(ebayCode);
                //LogApiHelper.WriteInformation(SerializeHelper.XmlSerializer(item));
                return item;
            }
            catch (Exception ex)
            {
                EbaySyncModel.Logger.WriteException(ex);
                LogApiHelper.WriteException(ex);
                return null;
            }
        }

        public static TransactionType GetItemTransactions(string ebayCode, DateTime startTime)
        {
            try
            {
                EbaySyncModel.Logger.Write("GetItemTransactions for ebayCode:{0} ", ebayCode);
                var call = new GetItemTransactionsCall
                {
                    ApiContext = GetApiContext(),
                    DetailLevelList = new DetailLevelCodeTypeCollection() {DetailLevelCodeType.ReturnAll}
                };
                var items = call.GetItemTransactions(ebayCode, startTime, startTime.AddDays(30));
                if (items.Count > 0)
                {
                    //LogApiHelper.WriteInformation(SerializeHelper.XmlSerializer(items));
                    return items.Cast<TransactionType>()
                        .OrderByDescending(item => item.TransactionID)
                        .Last();
                }
            }
            catch (Exception ex)
            {
                EbaySyncModel.Logger.WriteException(ex);
                LogApiHelper.WriteException(ex);
                return null;
            }
            return null;
        }
    }
}
