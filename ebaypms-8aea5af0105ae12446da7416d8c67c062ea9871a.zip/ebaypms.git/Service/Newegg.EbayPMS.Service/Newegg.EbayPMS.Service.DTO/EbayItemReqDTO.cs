﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Attributes;

namespace Newegg.EbayPMS.Service.DTO
{
    [Serializable]
    [RestService(RestName.Item)]
    [RestService(RestName.Item_ControlCode)]
    [RestService(RestName.Item_Excel)]
    public class EbayItemReqDTO:EbayItemDTO
    {
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
    }
}
