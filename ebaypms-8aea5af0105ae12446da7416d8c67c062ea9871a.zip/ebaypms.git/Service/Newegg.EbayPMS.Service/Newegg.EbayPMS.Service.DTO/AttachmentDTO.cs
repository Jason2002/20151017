﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.EbayPMS.Service.DTO
{
    [Serializable]
    public class AttachmentDTO
    {
        public int? RowId { get; set; }
        public string OrderNumber { get; set; }
        public string OrderType { get; set; }
        public string InUser { get; set; }
        public DateTime? InDate { get; set; }
        public string LastEditUser { get; set; }
        public DateTime? LastEditDate { get; set; }
        public string AttachmentType { get; set; }
        public string URL { get; set; }
        public string AttachmentName { get; set; }

        public const string OrderType_ControlCode = "902";

    }
}
