﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.EbayPMS.Service.Common;

namespace Newegg.EbayPMS.Service.DTO
{
    [Serializable]
    public class ItemOptionDTO
    {
        public string Category { get; set; }

        public string FieldName { get; set; }
        public string FieldValue { get; set; }
        public int? DisplayOrder { get; set; }
        public string FieldType { get; set; }
        public const string FieldType_Parts = "Parts";

        public bool IsParts
        {
            get { return FieldType.AreEqualsTo(FieldType_Parts); }
        }

        public bool BoolValue
        {
            get { return StringHelper.CheckBoolValue(FieldValue); }
        }
    }
}
