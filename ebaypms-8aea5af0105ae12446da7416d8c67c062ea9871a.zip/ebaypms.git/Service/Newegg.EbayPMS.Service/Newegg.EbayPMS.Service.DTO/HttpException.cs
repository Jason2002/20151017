﻿using System;
using Newegg.API.Exceptions;

namespace Newegg.ABS.CMS.Service.DTO
{
    public static class HttpStatusCodes
    {
        public const string NullHttpReq = "233001";
        public const string BizException = "233002";
        public const string BizConfirm = "233003";
        public const string AuthException = "233004";
        public const string TokenFailure = "233005";
    }

    public class HttpReqNullError : HttpError
    {
        public HttpReqNullError(string msg) : base(HttpStatusCodes.NullHttpReq, msg) { }
    }

    public class BizException : HttpError
    {
        public BizException(string msg) : base(HttpStatusCodes.BizException, msg) { }
        public BizException(Exception ex) : base(HttpStatusCodes.BizException, ex.Message) { }
        public BizException(string msg, params object[] args) : this(string.Format(msg, args)) { }
    }
}
