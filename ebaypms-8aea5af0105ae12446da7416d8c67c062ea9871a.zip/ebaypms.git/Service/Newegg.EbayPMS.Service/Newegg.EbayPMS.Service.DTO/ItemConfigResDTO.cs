﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.EbayPMS.Service.DTO
{
    [Serializable]
    public class ItemConfigResDTO
    {
        public List<string> StatusList { get; set; }
        public List<string> CategoryList { get; set; }
    }
}
