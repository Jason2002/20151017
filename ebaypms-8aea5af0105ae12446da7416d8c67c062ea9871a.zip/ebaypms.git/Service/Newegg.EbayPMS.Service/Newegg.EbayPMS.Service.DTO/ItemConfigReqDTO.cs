﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Attributes;

namespace Newegg.EbayPMS.Service.DTO
{
    [RestService(RestName.Config)]
    public class ItemConfigReqDTO    
    {

    }
}
