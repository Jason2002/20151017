﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Attributes;

namespace Newegg.EbayPMS.Service.DTO
{
    [Serializable]
    [RestService(RestName.Item_EbayCode)]
    [RestService(RestName.Item_ControlCode_EbayCode)]
    public class EbayCodeReqDTO:EbayItemDTO
    {

    }
}
