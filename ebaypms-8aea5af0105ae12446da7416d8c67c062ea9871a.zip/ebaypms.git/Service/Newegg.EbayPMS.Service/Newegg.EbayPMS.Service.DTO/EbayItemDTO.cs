﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.EbayPMS.Service.Common;

namespace Newegg.EbayPMS.Service.DTO
{
    [Serializable]
    public class EbayItemDTO
    {
        public int? RowId { get; set; }
        public string ControlCode { get; set; }
        public DateTime? InDate { get; set; }
        public string InUser { get; set; }
        public string InUserName { get; set; }
        public string WarehouseNumber { get; set; }
        public string ItemCode { get; set; }
        public string Description { get; set; }
        public decimal? OriginPOCost { get; set; }
        public string Category { get; set; }
        public string SerialNumber { get; set; }
        public string Status { get; set; }
        public string RMAPalletNumber { get; set; }
        public string Location { get; set; }
        public int? NotTested { get; set; }
        public string OtherParts { get; set; }
        public string DamageDescription { get; set; }
        public string TestingNote { get; set; }
        public string LastEditUser { get; set; }
        public string LastEditUserName { get; set; }
        public DateTime? LastEditDate { get; set; }

        public string EbayCode { get; set; }
        public string EbayTitle { get; set; }
        public decimal? FixedPrice { get; set; }
        public decimal? StartingPrice { get; set; }
        public decimal? ShippingFee { get; set; }
        public decimal? TotalPrice { get; set; }
        public int? ListedTimes { get; set; }
        public string TrackingNumber { get; set; }
        public DateTime? SubmitDate { get; set; }
        public string SubmitUser { get; set; }
        public string SubmitUserName { get; set; }
        public string Condition { get; set; }



        #region
        public string SKU { get; set; }
        public string ShippingMethod { get; set; }
        public DateTime? StartListDate { get; set; }
        public DateTime? EndListDate { get; set; }
        public bool? IsSold { get; set; }
        public DateTime? PaidDate { get; set; }
        public DateTime? ShippedDate { get; set; }
        public DateTime? ReceiveDate { get; set; }
        public string ListingStatus { get; set; }
        public string RelistedItemID { get; set; }
        //public string RelistParentID { get; set; }


        #endregion
        public List<AttachmentDTO> PictureList { get; set; }
        public List<ItemOptionDTO> ItemOptionList { get; set; }

        public string GetStatus()
        {
            if (!Status.IsNullOrEmpty())
            {
                return Status;
            }
            if (!EbayCode.IsNullOrEmpty()
                && ListingStatus.AreEqualsTo("Completed") //not reference ebay dll.
                && !PaidDate.HasValue
                && !ShippedDate.HasValue
                && !ReceiveDate.HasValue)
            {
                return ItemStatus.Ended;
            }
            else if (ReceiveDate.HasValue)
            {
                return ItemStatus.Received;
            }
            else if (ShippedDate.HasValue)
            {
                return ItemStatus.Shipped;
            }
            else if (PaidDate.HasValue)
            {
                return ItemStatus.Paid;
            }
            else if (!EbayCode.IsNullOrEmpty())
            {
                return ItemStatus.Listed;
            }
            else
            {
                return ItemStatus.Ready;
            }
        }

    }
}
