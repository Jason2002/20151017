﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.EbayPMS.Service.DTO
{
    public static class ItemStatus
    {
        public const string Created = "Created";
        public const string Ready = "Ready";
        public const string Listed = "Listed";
        public const string Ended = "Ended";
        public const string Paid = "Paid";
        public const string Shipped = "Shipped";
        public const string Received = "Received";
        public const string Void = "Void";
    }
}
