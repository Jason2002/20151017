﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Newegg.EbayPMS.Service.DTO
{
    public static class RestName
    {
        public const string Item = "/item";
        public const string Item_ControlCode = "/item/{ControlCode}";
        public const string Item_ControlCode_EbayCode  = "/item/{ControlCode}/EbayCode";
        public const string Item_EbayCode = "/EbayCode";
        public const string Item_Excel = "/item/excel";
        public const string Config = "/config";
    }
}
