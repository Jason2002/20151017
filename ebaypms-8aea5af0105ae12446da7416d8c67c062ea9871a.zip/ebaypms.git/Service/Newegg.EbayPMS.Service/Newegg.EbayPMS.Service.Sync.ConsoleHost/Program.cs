﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using eBay.Service.Core.Soap;
using Newegg.EbayPMS.Service.BizProcess;
using Newegg.EbayPMS.Service.Common;


namespace Newegg.EbayPMS.Service.Sync.ConsoleHost
{
    class Program
    {
        static void Main(string[] args)
        {



            EbaySyncModel.Logger = new ConsoleTrackingLog();



            while (true)
            {
                Console.WriteLine("Please input order to execute");
                Console.WriteLine("input 1 to getitem");
                Console.WriteLine("input 2 to sync all item");

                string order = Console.ReadLine();
                order = order.Trim().ToUpper();
                switch (order)
                {
                    case "1":
                        Console.WriteLine("Please input ebaycode to getItem");
                        string ebayCode = Console.ReadLine() ?? string.Empty;
                        EbaySyncModel.GetItem(ebayCode.Trim());
                        break;
                    case "2":
                        EbaySyncModel.SyncAllItem();
                        break;
                    case "EXIT":
                        break;

                }
            }
        }
    }


    class FileTrackingLog:ITrackingApiLog
    {
        public void Write(string msg, params object[] strs)
        {
            File.WriteAllText(DateTime.Now.ToString("yyyy-MM-dd") + "FileTrackingLog.txt"
                , DateTime.Now.ToString() + "  " + string.Format(msg, strs));
        }

        public void WriteException(Exception ex)
        {
            Write(ExceptionHandler.GetExceptionMessage(ex));
        }

        public void Close()
        {

        }
    }

    class ConsoleTrackingLog : ITrackingApiLog
    {

        public void Write(string msg, params object[] strs)
        {
            Console.WriteLine(string.Format(msg, strs));
        }

        public void WriteException(Exception ex)
        {
            Console.WriteLine(ExceptionHandler.GetExceptionMessage(ex));
        }

        public void Close()
        {

        }
    }
}
