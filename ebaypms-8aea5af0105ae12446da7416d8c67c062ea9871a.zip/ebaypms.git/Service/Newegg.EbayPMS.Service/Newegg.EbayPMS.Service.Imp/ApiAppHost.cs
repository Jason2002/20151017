﻿using System;
using Newegg.API.HttpExtensions;
using Newegg.API.ServiceHost;
using Newegg.EbayPMS.Service.Common;

namespace Newegg.EbayPMS.Service.Imp
{
    public class ApiAppHost : AppHostBase
    {

        public override void Init()
        {
            AssertHelper.AssertExceptionFactory = new HttpNullErrorFactory();
            base.Init();
            RequestFilters.Insert(0, InitResponse);
        }

        private void InitResponse(HttpRequestWrapper req, HttpResponseWrapper res, object dto)
        {
            if (req.Headers[HttpHeaders.Origin] != null)
            {
                res.AddHeader(HttpHeaders.AllowOrigin, req.Headers[HttpHeaders.Origin]);
            }
            if (req.Headers[HttpHeaders.RequestHeaders] != null)
            {
                res.AddHeader(HttpHeaders.AllowHeader, req.Headers[HttpHeaders.RequestHeaders]);
            }
            if (req.Headers[HttpHeaders.RequestMethod] != null)
            {
                try
                {
                    if (res.Headers[HttpHeaders.AccessMethods] != null)
                    {
                        res.Headers[HttpHeaders.AccessMethods] = string.Format("{0},{1}"
                            , res.Headers[HttpHeaders.AccessMethods]
                            , req.Headers[HttpHeaders.RequestMethod]);
                    }
                    else
                    {
                        res.AddHeader(HttpHeaders.AccessMethods, req.Headers[HttpHeaders.RequestMethod]);
                    }
                }
                catch (Exception)
                {
                    res.AddHeader(HttpHeaders.AccessMethods, req.Headers[HttpHeaders.RequestMethod]);
                }
            }
        }
    }

    public class HttpHeaders
    {
        public const string Origin = "Origin";
        public const string RequestHeaders = "Access-Control-Request-Headers";
        public const string RequestMethod = "Access-Control-Request-Method";

        public const string AllowHeader = "Access-Control-Allow-Headers";
        public const string AccessMethods = "Access-Control-Allow-Methods";
        public const string AllowOrigin = "Access-Control-Allow-Origin";
        public const string AccessControlAllowMethods = "POST, GET, PUT, DELETE, OPTIONS";
    }
}
