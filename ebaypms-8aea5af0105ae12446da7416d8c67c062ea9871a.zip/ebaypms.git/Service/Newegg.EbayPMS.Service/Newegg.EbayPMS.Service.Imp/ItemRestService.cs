﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Interfaces;
using Newegg.EbayPMS.Service.BizProcess;
using Newegg.EbayPMS.Service.Common;
using Newegg.EbayPMS.Service.DTO;

namespace Newegg.EbayPMS.Service.Imp
{
    public class ItemRestService : RestServiceBase<EbayItemReqDTO>
    {
        public override object OnGet(EbayItemReqDTO request)
        {
            string absoluteUrl = RequestContext.HttpReq.Request.Url.AbsolutePath.ToLower();
            if (absoluteUrl.EndsWith(RestName.Item)
                ||absoluteUrl.EndsWith(RestName.Item_Excel))
            {
                var list = EbayModel.QueryItems(request);
                //if (absoluteUrl.EndsWith(RestName.Item_Excel))
                //{
                //    ExportExcel(list);
                //    return null;
                //}
                return list;
            }
            else
            {
                return EbayModel.GetItem(request.ControlCode, true,true);
            }
        }
       
    }
}
