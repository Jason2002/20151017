﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.API.Interfaces;
using Newegg.EbayPMS.Service.BizProcess;
using Newegg.EbayPMS.Service.DTO;

namespace Newegg.EbayPMS.Service.Imp
{
    public class ItemConfigRestService:RestServiceBase<ItemConfigReqDTO>
    {
        public override object OnGet(ItemConfigReqDTO request)
        {
            return EbayModel.GetConfig();
        }
    }
}
