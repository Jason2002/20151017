﻿using System;
using Newegg.ABS.CMS.Service.DTO;
using Newegg.EbayPMS.Service.Common;


namespace Newegg.EbayPMS.Service.Imp
{
    class HttpNullErrorFactory : IAssertExceptionFactory
    {
        public Exception CreateException(string msg)
        {
            throw new HttpReqNullError(msg);
        }
    }
}
