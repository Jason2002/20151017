﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.ABS.CMS.Service.DTO;
using Newegg.API.Interfaces;
using Newegg.EbayPMS.Service.BizProcess;
using Newegg.EbayPMS.Service.Common;
using Newegg.EbayPMS.Service.DTO;

namespace Newegg.EbayPMS.Service.Imp
{
    public class EbayCodeRestService : RestServiceBase<EbayCodeReqDTO>
    {
        public override object OnPut(EbayCodeReqDTO request)
        {
            request.EbayCode.AssertIsNotEmpty("EbayCode");
            if (request.EbayCode.Trim().Length > 50)
            {
                throw new BizException("The max length of EbayID is 50 character.");
            }
            request.EbayCode = request.EbayCode.Trim();
            return EbayModel.SaveEbayCode(request);
        }

        public override object OnGet(EbayCodeReqDTO request)
        {
            return EbayModel.CheckEbayCode(request);
        }
    }
}
