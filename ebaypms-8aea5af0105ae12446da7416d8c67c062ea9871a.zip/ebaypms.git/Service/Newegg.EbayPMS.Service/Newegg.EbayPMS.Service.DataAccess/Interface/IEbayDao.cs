﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using Newegg.EbayPMS.Service.DTO;

namespace Newegg.EbayPMS.Service.DataAccess.Interface
{
    public interface IEbayItemDao
    {
        List<EbayItemDTO> QueryItem(string whereSql,EbayItemReqDTO paramDto);
        EbayItemDTO GetItem(string controlCode);
        List<EbayItemDTO> GetItemByEbayCode(string ebayCode);
        void UpdateItem(EbayItemDTO item);
        void InsertEbayDetail(EbayItemDTO item);
        void UpdateEbayDetail(EbayItemDTO item);
        EbayItemDTO GetEbayDetail(string ebayCode);
        List<ItemOptionDTO> GetItemDetail(string controlCode);
        List<ItemOptionDTO> GetCategoryList();

    }
}
