﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.EbayPMS.Service.DTO;

namespace Newegg.EbayPMS.Service.DataAccess.Interface
{
    public interface IItemAttachmentDao
    {
        List<AttachmentDTO> GetAttachments(string ordernumber, string orderType);
    }
}
