﻿

using System;

namespace Newegg.EbayPMS.Service.DataAccess
{
    public static class DaoFactory
    {
        public static T GetDao<T>()
            where T:class
        {
            return DaoManager<T>.Instance;
        }
    }
}
