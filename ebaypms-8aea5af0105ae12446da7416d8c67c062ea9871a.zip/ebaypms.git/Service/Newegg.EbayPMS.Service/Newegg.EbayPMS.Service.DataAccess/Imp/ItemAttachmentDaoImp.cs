﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Text;
using Newegg.EbayPMS.Service.DataAccess.Interface;
using Newegg.EbayPMS.Service.DTO;
using Newegg.Oversea.DataAccess;

namespace Newegg.EbayPMS.Service.DataAccess.Imp
{
    public class ItemAttachmentDaoImp:IItemAttachmentDao
    {
        public List<AttachmentDTO> GetAttachments(string ordernumber, string orderType)
        {
            var cmd = DataCommandManager.GetDataCommand("GetItemAttachment");
            return
                cmd.ExecuteEntityList<AttachmentDTO>(new AttachmentDTO
                {
                    OrderNumber = ordernumber,
                    OrderType = orderType
                });
        }
    }
}
