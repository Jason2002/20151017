﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Newegg.EbayPMS.Service.DataAccess.Interface;
using Newegg.EbayPMS.Service.DTO;
using Newegg.Oversea.DataAccess;

namespace Newegg.EbayPMS.Service.DataAccess.Imp
{
    public class EbayItemDaoImp : IEbayItemDao
    {
        public List<EbayItemDTO> QueryItem(string whereSql, EbayItemReqDTO paramDto)
        {
            var cmd = DataCommandManager.CreateCustomDataCommandFromConfig("QueryItem");
            cmd.CommandText = cmd.CommandText.Replace(CmdName.WhereStr, whereSql);
            return cmd.ExecuteEntityList<EbayItemDTO>(paramDto);
        }

        public EbayItemDTO GetItem(string controlCode)
        {
            var cmd = DataCommandManager.GetDataCommand("GetItem");
            return cmd.ExecuteEntity<EbayItemDTO>(new EbayItemDTO {ControlCode = controlCode});
        }

        public void UpdateItem(EbayItemDTO item)
        {
            var cmd = DataCommandManager.GetDataCommand("UpdateItem");
            cmd.ExecuteNonQuery(item);
        }

        public void InsertEbayDetail(EbayItemDTO item)
        {
            var cmd = DataCommandManager.GetDataCommand("InsertEbayDetail");
            cmd.ExecuteNonQuery(item);
        }

        public EbayItemDTO GetEbayDetail(string ebayCode)
        {
            var cmd = DataCommandManager.GetDataCommand("GetEbayDetail");
            return cmd.ExecuteEntity<EbayItemDTO>(new EbayItemDTO { EbayCode = ebayCode });
        }

        public List<ItemOptionDTO> GetItemDetail(string controlCode)
        {
            var cmd = DataCommandManager.GetDataCommand("GetItemDetail");
            return cmd.ExecuteEntityList<ItemOptionDTO>(new EbayItemDTO { ControlCode = controlCode });
        }


        public List<ItemOptionDTO> GetCategoryList()
        {
            var cmd = DataCommandManager.GetDataCommand("GetCategoryList");
            return cmd.ExecuteEntityList<ItemOptionDTO>();
        }


        public void UpdateEbayDetail(EbayItemDTO item)
        {
            var cmd = DataCommandManager.GetDataCommand("UpdateEbayDetail");
            cmd.ExecuteNonQuery(item);
        }


        public List<EbayItemDTO> GetItemByEbayCode(string ebayCode)
        {
            var cmd = DataCommandManager.GetDataCommand("GetItemByEbayCode");
            return cmd.ExecuteEntityList<EbayItemDTO>(new EbayItemDTO{EbayCode = ebayCode});
        }
    }
}
