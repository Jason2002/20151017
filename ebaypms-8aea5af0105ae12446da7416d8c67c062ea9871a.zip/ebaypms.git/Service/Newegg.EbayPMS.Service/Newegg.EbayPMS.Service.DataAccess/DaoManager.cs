﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace Newegg.EbayPMS.Service.DataAccess
{
    public static class DaoManager<T>
        where T : class
    {
        private static T s_instance;
        private static object Sync_Lock = new object();

        public static T Instance
        {
            get
            {
                if (s_instance == null)
                {
                    lock (Sync_Lock)
                    {
                        if (s_instance == null)
                        {
                            s_instance = GetInstance();
                        }
                    }
                }
                return s_instance;
            }
        }



        private static T GetInstance()
        {
            var assembly = Assembly.GetAssembly(typeof (DaoManager<>));
            var genType = typeof (T);
            if (!genType.IsInterface)
            {
                throw new ArgumentException(string.Format("{0} is not interface.",genType));
            }
            foreach (var type in assembly.GetTypes())
            {
                if (type!=genType
                    && genType.IsAssignableFrom(type))
                {
                    return Activator.CreateInstance(type) as T;
                }
            }
            throw  new ArgumentException(string.Format("Cannot find any imp type for {0}.",genType));
        }
    }
}
