﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace Newegg.EbayPMS.Service.Common
{
    public static class LogHelper
    {
        private static readonly string Category;
        private static Queue<string> s_LogList = new Queue<string>(100);
        private static object sync_Lock = new object();

        static LogHelper()
        {
            Category = AppDomain.CurrentDomain.FriendlyName;           
        }  

        public static void WriteLog(string msg)
        {
            if (msg.IsNullOrEmpty())
            {
                return;
            }
            lock (sync_Lock)
            {
                s_LogList.Enqueue(msg);               
            }
            ThreadPool.QueueUserWorkItem(state =>
            {
                try
                {
                    WriteCore();
                }
                catch { }
            }, null);
        }   

        private static void WriteCore()
        {
            StringBuilder msgStr = new StringBuilder(1024*24);
            while (s_LogList.Count > 0)
            {
                string log = null;
                lock (sync_Lock)
                {
                    if (s_LogList.Count > 0)
                    {
                        log = s_LogList.Dequeue();
                    }
                }
                if (log != null)
                {
                    msgStr.Append(log);
                }
            }

            if (msgStr.Length > 0)
            {
                FileLogHelper.Write(msgStr.ToStringEx());
            }
        }     
    } 
}
