﻿using System;

namespace Newegg.EbayPMS.Service.Common
{
    static class FileLogHelper
    {
        private readonly static string ExceptionLog = "ExceptionLog";
        private readonly static object m_FileObject = new object();

        private static string GetLogFileFullPath()
        {
            return string.Format("{0}\\{1}\\{2}.txt"
                , ExceptionLog
                , DateTime.Now.ToString("yyyy-MM")
                , DateTime.Now.ToString("yyyy-MM-dd"));
        }

        public static void Write(string msg, string fileName)
        {
            FileHelper.Append(msg, fileName);
        }

        public static void Write(string msg)
        {
            try
            {
                lock (m_FileObject)
                {
                    Write(msg, GetLogFileFullPath());
                }
            }
            catch { }
        }
    }
}
