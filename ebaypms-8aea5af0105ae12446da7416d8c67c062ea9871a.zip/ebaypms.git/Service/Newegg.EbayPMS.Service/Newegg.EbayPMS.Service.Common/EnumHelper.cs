using System;
using System.Collections.Generic;
using System.Reflection;


namespace Newegg.EbayPMS.Service.Common
{  
    public static class EnumHelper
    {
        class EnumItem {
            public int EnumValue {get;set;}
            public string Code {get;set;}
            public string DispalyName {get;set;}
        }

        private static readonly List<Tuple<Type, List<EnumItem>>> s_EnumCollection =
            new List<Tuple<Type, List<EnumItem>>>(50);

        public static string GetDispalyName(this Enum en)
        {
            var enumItem = GetEnumItem(en);
            if (enumItem != null)
            {
                return enumItem.DispalyName;
            }
            return string.Empty;
        }

        public static string GetDispalyName<T>(string codeStr)
        {
            if (!typeof(T).IsEnum)
            {
                throw new ArgumentNullException(string.Format("{0} is not enum.", typeof(T)));
            }
            if (codeStr.IsNullOrEmpty())
            {
                return string.Empty;
            }
            var enumItem = GetEnumItemList(typeof(T)).Find(enItem =>
            {
                return enItem.Code.AreEqualsTo(codeStr);
            });
            if (enumItem != null)
            {
                return enumItem.DispalyName;
            }
            return codeStr;
        }

        public static string GetDispalyName<T>(int? code)
        {
            if (!typeof(T).IsEnum)
            {
                throw new ArgumentNullException(string.Format("{0} is not enum.", typeof(T)));
            }
            if (!code.HasValue)
            {
                return string.Empty;
            }
            return GetDispalyName<T>(code.ToStringEx());
        }


        public static string GetCode(this Enum en)
        {
            var enumItem = GetEnumItem(en);
            if (enumItem != null)
            {
                return enumItem.Code;
            }
            return string.Empty;        
        }

        private static EnumItem GetEnumItem(Enum en)
        {
            int enValue = Convert.ToInt32(en);

            return GetEnumItemList(en.GetType()).Find(enItem =>
            {
                return enItem.EnumValue == enValue;
            });
        }

      
        public static T GetEnum<T>(this string codeStr)
        {
            if (!typeof(T).IsEnum)
            {
                throw new ArgumentNullException(string.Format("{0} is not enum.", typeof(T)));
            }

            codeStr.AssertIsNotEmpty("codeStr");
            var enumItem = GetEnumItemList(typeof(T)).Find(enItem =>
            {
                return enItem.Code.AreEqualsTo(codeStr);
            });
            if (enumItem != null)
            {
                return (T)(object)enumItem.EnumValue;
            }
            throw new ArgumentException(codeStr);
        }

        public static T GetEnum<T>(this int? code)
        {
            if (!typeof(T).IsEnum)
            {
                throw new ArgumentNullException(string.Format("{0} is not enum.", typeof(T)));
            }
            if (!code.HasValue)
            {
                throw new ArgumentNullException("code");
            }
            return GetEnum<T>(code.ToStringEx());
        }

        private static List<EnumItem> GetEnumItemList(Type type)
        {
            type.AssertIsNotNull();
            var list = GetEnumItemListFromCollection(type);
            if (list == null)
            {
                list = InitEnumType(type);
            }           
            return list;
        }

        private static List<EnumItem> InitEnumType(Type type)
        {
            if (!type.IsEnum)
            {
                throw new ArgumentException("{0} is not enum.",type.Name);
            }
            List<EnumItem> enumList = new List<EnumItem>();
            foreach (var name in System.Enum.GetNames(type))
            {
                FieldInfo fieldInfo = type.GetField(name);
                Attribute attri = Attribute.GetCustomAttribute(fieldInfo, typeof(EnumCodeAttribute));
                EnumCodeAttribute enAttri = null;
                if (attri == null)
                {
                    enAttri = new EnumCodeAttribute(name, name);
                }
                else
                {                    
                    enAttri = attri as EnumCodeAttribute;
                    if (enAttri.Code.IsNullOrEmpty())
                    {
                        enAttri.Code = name;
                    }
                    if (enAttri.DispalyName.IsNullOrEmpty())
                    {
                        enAttri.DispalyName = name;
                    }
                }
                EnumItem item = new EnumItem();
                item.Code = enAttri.Code;
                item.DispalyName = enAttri.DispalyName;
                item.EnumValue =(int)(Enum.Parse(type, name));
                

                enumList.Add(item);
            }
            lock (s_EnumCollection)
            {
                var enumItemList = GetEnumItemListFromCollection(type);
                if (enumItemList == null)
                {
                    Tuple<Type, List<EnumItem>> tp = new Tuple<Type, List<EnumItem>>(type, enumList);
                    s_EnumCollection.Add(tp);
                }
            }
            return enumList;
        }

        private static List<EnumItem> GetEnumItemListFromCollection(Type type)
        {
            var enumType =  s_EnumCollection.Find(item => {
                return item.Item1 == type;
            });
            if (enumType != null)
            {
                return enumType.Item2;
            }
            return null;
        }

    }


    [Serializable]
    public enum ExtraDataEnum
    {
        [EnumCode("Select", "")]
        Select,

        [EnumCode("All", "")]
        All
    }
}

