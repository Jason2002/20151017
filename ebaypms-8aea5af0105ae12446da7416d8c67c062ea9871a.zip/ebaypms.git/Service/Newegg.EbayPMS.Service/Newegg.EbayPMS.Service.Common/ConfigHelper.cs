using System;
using System.Configuration;

namespace Newegg.EbayPMS.Service.Common
{
    public static class ConfigHelper
    {
        private static object Sync_Lock = new object();

        #region
        private static string s_ApplicationPath;
        #endregion


        static ConfigHelper()
        {
            InitConfiguration();
        }

        private static void InitConfiguration()
        {
            lock (Sync_Lock)
            {
                s_ApplicationPath = AppDomain.CurrentDomain.BaseDirectory;
            }
        }

        private static bool GetBoolAppSetting(string nodeName, bool defaultValue)
        {
            string config = ConfigurationManager.AppSettings[nodeName];
            if (config == null)
            {
                return defaultValue;
            }
            return StringHelper.CheckBoolValue(config);
        }

        private static string GetStringAppSetting(string nodeName, string defaultValue)
        {
            string config = ConfigurationManager.AppSettings[nodeName];
            if (config.IsNullOrEmpty())
            {
                config = defaultValue;
            }
            return config.ToStringEx().Trim();
        }

        private static decimal? GetDecimalAppSetting(string nodeName, decimal? defaultValue)
        {
            string config = ConfigurationManager.AppSettings[nodeName];
            decimal dec;
            if (Decimal.TryParse(config, out dec))
            {
                return dec;
            }
            return defaultValue;
        }
        

        public static string ApplicationPath
        {
            get
            {
                return s_ApplicationPath;
            }
        }

        
        /// <summary>
        /// ָʾ�Ƿ��ò�������.
        /// </summary>
        public static bool IsMock
        {
            get
            {
                return GetBoolAppSetting("IsMock", false);
            }
        }

        public static string EbayConfigSysName
        {
            get { return GetStringAppSetting("EbayConfigSysName", "EbayPMS"); }
        }


        /// <summary>
        /// ����ָʾ����,GQC,GDEVȫ��ISDebug
        /// </summary>
        public static bool IsDebug
        {
            get
            {
                return GetBoolAppSetting("IsDebug", false);
            }
        }
    }
}
