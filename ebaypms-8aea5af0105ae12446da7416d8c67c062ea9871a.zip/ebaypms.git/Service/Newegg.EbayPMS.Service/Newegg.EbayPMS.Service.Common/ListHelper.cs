using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;

namespace Newegg.EbayPMS.Service.Common
{
    public static class ListHelper 
    {    
        public static bool IsNullOrEmpty(this ICollection collection)
        {
            return collection == null 
                || collection.Count == 0;
        }

       
        public static IEnumerable<TSource> DistinctEx<TSource>(this IEnumerable<TSource> source
            , Func<TSource, TSource, bool> predicate)
        {
            if (source == null)
            {
                return System.Linq.Enumerable.Empty<TSource>();
            }
            List<TSource> list = new List<TSource>(source.Count<TSource>());
            foreach (var item in source)
            {
                if (!list.Exists(item1 => predicate(item, item1)))
                {
                    list.Add(item);
                }
            }
            return list;
        }
    }   
}
