using System;

namespace Newegg.EbayPMS.Service.Common
{
    public static class DateTimeHelper
    {

        private static readonly DateTime JavaStartDate = DateTime.Parse("1970-01-01");


        public static DateTime? GetLocalTime(this DateTime? date)
        {
            if (date.HasValue)
            {
                DateTime dt = new DateTime(date.Value.Year, date.Value.Month, date.Value.Day
                    ,date.Value.Hour,date.Value.Minute,date.Value.Second);
                return dt;
            }
            else
            {
                return date;
            }           
        }

        public static DateTime GetDate()
        {
            return GetDate(DateTime.Now);
        }

        public static DateTime GetDate(DateTime date)
        {
            return new DateTime(date.Year, date.Month, date.Day);
        }

        public static DateTime GetDateTime(DateTime date)
        {
            return new DateTime(date.Year, date.Month, date.Day, date.Hour, date.Minute, date.Second, date.Millisecond);
        }

        public static DateTime GetDateTime()
        {
            return GetDateTime(DateTime.Now);
        }

        public static string GetCutOffTime(DateTime date)
        {
            return date.ToString("hh:mm tt");
        }

        public static DateTime GetDateTime(DateTime day, string cutoffTime)
        {
            if (StringHelper.IsNullOrEmpty(cutoffTime))
            {
                cutoffTime = string.Empty;
            }
            return DateTime.Parse(string.Format("{0} {1}", day.ToString("yyyy-MM-dd"), cutoffTime.Trim()));
        }

        public static DateTime GetDateTime(DateTime day, DateTime cutoffTime)
        {
            return GetDateTime(day, GetCutOffTime(cutoffTime));
        }

        public static DateTime GetDateTime(string cutoffTime)
        {
            return GetDateTime(DateTime.Now, cutoffTime);
        }

        public static DateTime GetDayLastSecond(this DateTime day)
        {
            return day.Date.AddDays(1).AddSeconds(-1);
        }

        public static DateTime? GetDayLastSecond(this DateTime? day)
        {
            if (!day.HasValue)
            {
                return null;
            }
            return GetDayLastSecond(day.Value);
        }

        public static DateTime? GetMonthLastDay(this DateTime? day) 
        {
            if (!day.HasValue)
            {
                return null;
            }  
            return new DateTime(day.Value .Year ,day.Value .Month ,1).AddMonths(1).AddSeconds (-1);        
        }

        public static DateTime? GetMonthFirstDay(this DateTime? day)
        {
            if (!day.HasValue)
            {
                return null;
            }
            return new DateTime(day.Value.Year, day.Value.Month, 1);
        }

        public static long? ToJavaDate(this DateTime? date)
        {
            if (date.HasValue)
            {
                return ToJavaDate(date.Value);
            }
            return null;
        }

        public static long ToJavaDate(this DateTime date)
        {
            if (date > JavaStartDate)
            {
                return (long)(date - JavaStartDate).TotalMilliseconds;
            }
            return 0;

        }

    }
}
