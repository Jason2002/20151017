﻿using System;
using System.Net;

namespace Newegg.EbayPMS.Service.Common
{
    public static class NetHelper
    {
        public static string GetAddress(string url)
        {
            if (url.IsNullOrEmpty())
            {
                return string.Empty;
            }

            if (url.IndexOf("://")<0)
            {
                url = "http://" + url;
            }
            var uri = new Uri(url);
            IPAddress[] addressList = null;
            try
            {
                addressList = Dns.GetHostAddresses(uri.Host);
            }
            catch (System.Net.Sockets.SocketException)
            {
                throw new Exception(string.Format("Cann't get host by address[{0}]",uri.Host));
            }

            string ipAddress = uri.Host;
            if (addressList != null)
            {
                foreach (var address in addressList)
                {
                    if (!address.IsIPv6LinkLocal)
                    {
                        ipAddress = address.ToStringEx();
                    }
                }
            }
            return url.Replace(uri.Host, ipAddress);
        }
    }
}
