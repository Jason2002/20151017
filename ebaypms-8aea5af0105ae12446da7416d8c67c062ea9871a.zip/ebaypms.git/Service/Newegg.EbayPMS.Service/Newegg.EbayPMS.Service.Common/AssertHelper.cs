﻿using System;
using System.Collections;

namespace Newegg.EbayPMS.Service.Common
{

    public interface IAssertExceptionFactory
    {
        Exception CreateException(string msg);
    }


    public class ArgumentNullExceptionFactory : IAssertExceptionFactory
    {
        public Exception CreateException(string msg)
        {
            return new ArgumentNullException(msg);
        }
    }


    public static class AssertHelper
    {
        public static IAssertExceptionFactory s_ExceptionFactory;
        public static object s_lock = new object();

        public static IAssertExceptionFactory AssertExceptionFactory
        {
            get
            {
                if (s_ExceptionFactory == null)
                {
                    lock (s_lock)
                    {                       
                        if (s_ExceptionFactory == null)
                        {
                            s_ExceptionFactory = new ArgumentNullExceptionFactory();
                        }
                    }
                }
                return s_ExceptionFactory;
            }
            set
            {
                lock (s_lock)
                {
                    s_ExceptionFactory = value;
                }
            }
        }

        public static void AssertIsNotEmpty(this string str)
        {
            AssertIsNotEmpty(str, null);
        }

        public static void AssertIsNotEmpty(this string str,string paramName)
        {
            if (StringHelper.IsNullOrEmpty(str))
            {
                ThrowArgumentNullException(paramName);
            }
        }

        public static void AssertIsTrue(this bool value)
        {
            AssertIsTrue(value, null);
        }

        public static void AssertIsTrue(this bool value,string paramName)
        {
            if (!value)
            {
                ThrowArgumentNullException(paramName);
            }
        }

        public static void AssertIsNotNull(this object obj)
        {
            AssertIsNotNull(obj, null);
        }

        public static void AssertIsNotNull(this object obj,string paramName)
        {
            if (obj is ValueType)
            {
                return;
            }
            if (obj == null)
            {
                ThrowArgumentNullException(paramName);
            }
        }

        private static void ThrowArgumentNullException(string paramName)
        {
            string msg = string.Empty;
            if (!paramName.IsNullOrEmpty())
            {
                msg = string.Format("{0} is null.", paramName);
            }
            throw AssertExceptionFactory.CreateException(msg);           
        }


        public static void AssertHasValue<T>(this Nullable<T> obj)
            where T : struct 
        {
            AssertHasValue(obj, null); 
        }

        public static void AssertHasValue<T>(this Nullable<T> obj, string paramName)
            where T : struct
        {           
            if (obj.HasValue)
            {
                return;
            }
            ThrowArgumentNullException(paramName);
        }

        public static void AssertIsNotEmpty(this ICollection collection)
        {
            AssertIsNotEmpty(collection, string.Empty);
        }

        public static void AssertIsNotEmpty(this ICollection collection, string paramName)
        {
            AssertIsNotNull(collection, paramName);
            if (collection.Count == 0)
            {
                ThrowArgumentNullException(paramName);
            }
        }

        //public static void AssertMoreThan(this decimal? num,decimal num2 ,string paramName)
        //{
        //    num.AssertHasValue(paramName);
        //    if (num > num2)
        //    {
        //        return;
        //    }
        //    ThrowArgumentNullException(paramName);
        //}

        //public static void AssertLessThan<T>(this T? num, T num2, string paramName)
        //    where T:struct
        //{
        //    num.AssertHasValue(paramName);
        //    IComparable numCom = num as IComparable;
        //    int resutl = numCom.CompareTo(num2);
        //    if(resutl = 


        //    //if (num < num2)
        //    //{
        //    //    return;
        //    //}
        //    ThrowArgumentNullException(paramName);
        //}

        //public static void AssertMoreOrEqual(this decimal? num, decimal num2, string paramName)
        //{
        //    num.AssertHasValue(paramName);
        //    if (num >= num2)
        //    {
        //        return;
        //    }
        //    ThrowArgumentNullException(paramName);
        //}

        //public static void AssertLessOrEqual(this decimal? num, decimal num2, string paramName)
        //{
        //    num.AssertHasValue(paramName);
        //    if (num <= num2)
        //    {
        //        return;
        //    }
        //    ThrowArgumentNullException(paramName);
        //}

        //private static int CompareTo<T>(T t1, T t2)
        //{
        //    IComparable comT1 = t1 as IComparable;
        //    if (comT1 != null)
        //    {
        //        return comT1.CompareTo(t2);
        //    }
            

        //}

    }

}
