﻿using System;
using System.IO;
using System.Text;

namespace Newegg.EbayPMS.Service.Common
{
    public static class FileHelper
    {
        public readonly static string ApplicationBase;

        static FileHelper()
        {
            ApplicationBase = AppDomain.CurrentDomain.SetupInformation.ApplicationBase;
        }

        public static string GetReadFilePath(string path)
        {
            if (path.IsNullOrEmpty())
            {
                return string.Empty;
            }
            if (!ContainRootPath(path))
            {
                path = Path.Combine(ApplicationBase, path.Trim('\\'));
            }

            if (!File.Exists(path))
            {
                return string.Empty;
            }
            return Path.GetFullPath(path);
        }
        
        public static string GetDirectoryPath(string path)
        {
            if (path.IsNullOrEmpty())
            {
                return string.Empty;
            }
            if (!ContainRootPath(path))
            {
                path = Path.Combine(ApplicationBase, path.Trim('\\'));
            }
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
            return Path.GetFullPath(path);
        }

        public static bool ContainRootPath(string path)
        {
            if (path != null)
            {                
                int length = path.Length;
                if (length >= 2)
                {
                    //c:
                    if(path[1] == Path.VolumeSeparatorChar)
                    {
                        return true;
                    }
                    // 两个斜杠,表示远程驱动.\\wcmis234
                    if(path.StartsWith(@"\\"))
                    {
                        return true;
                    }
                }
            }
            return false;

        }


        public static string ReadAllText(string fileName, Encoding encoding)
        {
            var path = GetReadFilePath(fileName);
            if (path.IsNullOrEmpty())
            {
                return string.Empty;
            }
            if (encoding == null)
            {
                encoding = Encoding.UTF8;
            }
            return File.ReadAllText(path, encoding);
        }
       
        public static string GetWriteFileName(string fileName)
        {
            if (!ContainRootPath(fileName))
            {
                fileName = Path.Combine(ApplicationBase, fileName.Trim('\\'));
            }
            return fileName;
        }

        public static void Write(string msg,string fileName, Encoding encoding,bool isOverride)
        {
            if (msg.IsNullOrEmpty())
            {
                return;
            }

            fileName = GetWriteFileName(fileName);
            var dir = Path.GetDirectoryName(fileName);
            if (!Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }
            if (encoding == null)
            {
                encoding = Encoding.UTF8;
            }
            if(isOverride
                && File.Exists(fileName))
            {
                File.Delete(fileName);
            }
            File.AppendAllText(fileName,msg, encoding);
        }

        public static void Append(string msg, string fileName)
        {
            Write(msg, fileName, Encoding.UTF8,false);
        }

        public static void OverWrite(string msg,string fileName)
        {
            Write(msg,fileName,Encoding.UTF8,true);
        }
    }
}
