﻿using System.IO;

namespace Newegg.EbayPMS.Service.Common
{
    public static class StreamHelper
    {
        public static void CopyStream(Stream sourceStream, Stream destStream)
        {
            byte[] buffer = new byte[0x2000];
            int count = 0;
            while ((count = sourceStream.Read(buffer, 0, buffer.Length)) > 0)
            {
                destStream.Write(buffer, 0, count);
            }
        }

        public static byte[] GetBytes(Stream inputStream)
        {
            if (!inputStream.CanRead)
            {
                return null;
            }
            if (inputStream.CanSeek)
            {
                inputStream.Position = 0;
            }

            using (MemoryStream ms = new MemoryStream())
            {
                CopyStream(inputStream, ms);
                if (ms.Length > 0)
                {
                    return ms.ToArray();
                }
            }
            return null;
        }

    }
}
