﻿using System;
using System.Collections;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Xml;
using System.Xml.Serialization;

namespace Newegg.EbayPMS.Service.Common
{
    public static class SerializeHelper
    {
        public static string CustomXmlSerializer(object serialObject, string outputNodeName)
        {
            if (serialObject == null) { return string.Empty; }
           

            XmlDocument document = new XmlDocument();
            XmlNode root = document.CreateNode(XmlNodeType.Element, "root", string.Empty);
            document.AppendChild(root);

            Type type = serialObject.GetType();
            string typeNameOfString = typeof(string).FullName;

            XmlNode node = root;

            if (!StringHelper.IsNullOrEmpty(outputNodeName))
            {
                node = document.CreateNode(XmlNodeType.Element, outputNodeName, string.Empty);
                root.AppendChild(node);
                //node = tempNode;
            }

            foreach (PropertyInfo proInfo in type.GetProperties())
            {
                if (!proInfo.CanRead) { continue; }

                object[] attrs = proInfo.GetCustomAttributes(typeof(IgnoreSerializeAttribute), false);
                if (attrs != null && attrs.Length > 0) continue;

                object v;
                string value;
                string name = proInfo.Name;

                if (proInfo.PropertyType.IsValueType || proInfo.PropertyType.FullName == typeNameOfString)
                {
                    v = proInfo.GetValue(serialObject, null);
                    if (v == null)
                    {
                        continue;
                    }
                    else
                    {
                        value = v.ToString();
                    }
                }
                else
                {
                    continue;
                }

                XmlNode newNode = document.CreateNode(XmlNodeType.Element, name, string.Empty);
                newNode.InnerText = value;
                node.AppendChild(newNode);
            }

            return root.InnerXml;
        }

        public static string CustomXmlSerializer(this ICollection collection, string nodeName, string childNodeName)
        {
            if (collection == null)
            {
                return string.Empty;
            }

            StringBuilder xmlBuilder = new StringBuilder(collection.Count * 36);
            if (!StringHelper.IsNullOrEmpty(nodeName))
            {
                xmlBuilder.Append(string.Format("<{0}>", nodeName));
            } 
            foreach (var item in collection)
            {
                xmlBuilder.Append(CustomXmlSerializer(item, childNodeName));
            }
            if (!StringHelper.IsNullOrEmpty(nodeName))
            {
                xmlBuilder.Append(string.Format("</{0}>", nodeName));
            }
            return xmlBuilder.ToString();
        }



        public static string JsonSerializer(object data)
        {
            return ServiceStack.Text.JsonSerializer.SerializeToString(data);
        }

        public static T JsonDeserialize<T>(string json)
        {
            return ServiceStack.Text.JsonSerializer.DeserializeFromString<T>(json);
        }

        public static string XmlSerializer(object serialObject)
        {
            StringBuilder sb = new StringBuilder(0x1388);
            XmlSerializer serializer = new XmlSerializer(serialObject.GetType());
            using (TextWriter writer = new StringWriter(sb))
            {
                serializer.Serialize(writer, serialObject);
                return writer.ToString();
            }
        }

        public static T XmlDeserialize<T>(string str)
        {
            XmlSerializer serializer = new XmlSerializer(typeof(T));
            using (TextReader reader = new StringReader(str))
            {
                return (T)serializer.Deserialize(reader);
            }
        }

        public static T DeepClone<T>(T sourceObject)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                new BinaryFormatter().Serialize(ms, sourceObject);
                ms.Flush();
                ms.Position = 0;
                return (T)new BinaryFormatter().Deserialize(ms);
            }
        }

    }

    [AttributeUsage(AttributeTargets.Property, AllowMultiple = false)]
    public class IgnoreSerializeAttribute : Attribute
    {

    }
}
