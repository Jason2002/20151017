using System;
using System.Collections.Generic;
using System.Web;

namespace Newegg.EbayPMS.Service.Common
{
    public static class StringHelper
    {

        public static string MakeSafeSql(string inputSQL)
        {
            string s = inputSQL;
            s = inputSQL.Replace("'", "''");
            s = s.Replace("[", "[[]");
            s = s.Replace("%", "[%]");
            s = s.Replace("_", "[_]");
            return s;
        }

        public static string MakeSafeExcelStr(string inputStr)
        {
            if (inputStr.IsNullOrEmpty())
            {
                return string.Empty;
            }
            inputStr = HttpUtility.HtmlEncode(inputStr);
            //inputStr = inputStr.Replace("=", "=3D");
            //inputStr = inputStr.Replace("'", string.Empty);
            return inputStr;
        }

        public static bool IsNullOrEmpty(this string value)
        {
            if (value == null)
            {
                return true;
            }
            if (value.Length == 0)
            {
                return true;
            }
            return value.Trim().Length == 0;
        }

        public static bool AreEqualsTo(this string strA, string strB)
        {
            if (object.ReferenceEquals(strA, strB))
            {
                return true;
            }
            strA = strA ?? string.Empty;
            strB = strB ?? string.Empty;
            return String.Compare(strA, strB, true) == 0;
        }

        public static bool CheckBoolValue(string value)
        {
            if (value.IsNullOrEmpty())
            {
                return false;
            }
            else
            {
                switch (value.ToUpper().Trim())
                {
                    case "Y":
                    case "1":
                    case "TRUE":
                        return true;

                    default:
                        return false;
                }
            }

        }

        public static string GetBoolString(bool value)
        {
            return value ? "1" : "0";
        }

        public static string GetYesNoString(bool value)
        {
            return value ? "Yes" : "No";
        }

        public static string GetYesNoShortString(bool value)
        {
            return value ? "Y" : "N";
        }

        public static string ToUpperEx(this string strA)
        {
            if (strA == null)
            {
                return string.Empty;
            }
            return strA.ToUpper();
        }

        public static string TrimEx(this string strA)
        {
            if (strA == null)
            {
                return string.Empty;
            }
            return strA.Trim();
        }

        public const string ALL_DESCRIPTION = "All";
        public const string ALL_CODE = "All";

        /// <summary>
        /// ��\n�滻Ϊ\r\n
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string ReplaceNewLine(string str)
        {
            return ReplaceNewLine(str, Environment.NewLine);
        }

        public static string ReplaceNewLine(string str,string replaceStr)
        {
            if (str == null)
            {
                return str;
            }
            return str.Replace(Environment.NewLine, "\n").Replace("\n", replaceStr);
        }

        public static string ToStringEx(this object str, string defaultStr)
        {
            if (str != null) return str.ToString();
            return defaultStr ?? string.Empty;
        }

        public static string ToStringEx(this string str, string defaultStr)
        {
            if (!str.IsNullOrEmpty()) return str;
            return defaultStr ?? string.Empty;
        }

        public static string ToStringEx(this object str)
        {
            return ToStringEx(str, string.Empty);
        }

        public static int StringCompare(this string a, string b)
        {
            if (a == null && b == null) return 0;
            else if (a == null) return -1;
            else if (b == null) return 1;
            else return a.CompareTo(b);
        }

        public static bool IsIn(this string str, params string[] strs)
        {
            if (str.IsNullOrEmpty()
                || strs.IsNullOrEmpty())
            {
                return false;
            }
            foreach (var item in strs)
            {
                if (str.AreEqualsTo(item))
                {
                    return true;
                }
            }
            return false;
        }

        public static string[] SplitEx(this string str,params char[] separator)
        {
            var list = new List<string>();
            if (!str.IsNullOrEmpty())
            {
                var strs = str.Split(separator, StringSplitOptions.RemoveEmptyEntries);
                if (!strs.IsNullOrEmpty())
                {
                    foreach (var subStr in strs)
                    {
                        if (!subStr.IsNullOrEmpty())
                        {
                            list.Add(subStr);
                        }
                    }
                }
            }
            return list.ToArray();
        }

    }
}
