﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newegg.Framework.Tools.Log;
using Newegg.FrameworkAPI.SDK;


namespace Newegg.EbayPMS.Service.Common
{
    public static class LogApiHelper
    {
        public static void WriteLog(LogEntry entity)
        {
            
            if (entity != null)
            {
                Task.Factory.StartNew(() =>
                {
                    try
                    {
                        entity.GlobalName = SdkConfig.Instance.LogConfig.LogGlobal;
                        entity.LocalName = SdkConfig.Instance.LogConfig.LogLocal;
                        Newegg.FrameworkAPI.SDK.Log.LogHelper.WriteLog(entity);
                    }
                    catch (Exception ex)
                    {
                        ExceptionHandler.LogOnly(ex);
                    }
                });
            }
        }

        public static void WriteInformation(params string[] msgsStrings)
        {
            if (msgsStrings == null || msgsStrings.Length == 0) return;
            var msgBuilder = new StringBuilder(1024);
            foreach (var msg in msgsStrings)
            {
                if (!msg.IsNullOrEmpty())
                {
                    msgBuilder.AppendLine(msg);
                }
            }
            if (msgBuilder.Length == 0)
            {
                return;
            }
            Write(null, msgBuilder.ToStringEx());
        }

        public static void Write(string categoryName, string msg)
        {
            if (msg.IsNullOrEmpty()) return;
            if (categoryName.IsNullOrEmpty())
            {
                categoryName = "Information";
            }
            var logEntry = new LogEntry
            {
                CategoryName = categoryName,
                Content = msg,
                LogType = "I"
            };
            WriteLog(logEntry);
        }


        public static void WriteException(Exception ex)
        {
            if (ex == null) return;
            var logEntry = new LogEntry
            {
                CategoryName = "ERROR",
                Content = ExceptionHandler.GetExceptionMessage(ex),
                LogType = "E"
            };
            WriteLog(logEntry);
        }
    }
}
