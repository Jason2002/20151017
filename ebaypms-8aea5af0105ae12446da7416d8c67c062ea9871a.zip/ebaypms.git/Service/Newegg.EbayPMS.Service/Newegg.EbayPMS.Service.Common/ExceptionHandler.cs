﻿using System;
using System.Net;
using System.Text;


namespace Newegg.EbayPMS.Service.Common
{
    public static class ExceptionHandler
    {

        private static string s_localMachineIP = Dns.GetHostAddresses(Dns.GetHostName())[0].ToString();

        public static void LogOnly(Exception ex)
        {
            LogHelper.WriteLog(GetExceptionMessage(ex));
        }

        public static void LogAndMail(string errorMsg)
        {
            string msg = string.Format("Message:{0}{1}StackTrace:{2}"
                , errorMsg
                , Environment.NewLine
                , Environment.StackTrace);
            LogHelper.WriteLog(msg);
        }

        public static void LogAndMail(Exception ex)
        {
            LogOnly(ex);
            MailOnly(ex);
        }

        public static void MailOnly(Exception ex)
        {
            try
            {
                if (!ConfigHelper.IsDebug)
                {

                    //string error = GetExceptionMessage(ex);
                    //MailSender.SendExceptionMail(ex.Message + "_" + AppDomain.CurrentDomain.FriendlyName
                    //    , s_localMachineIP
                    //    , AppDomain.CurrentDomain.FriendlyName
                    //    , Assembly.GetExecutingAssembly().GetName().Version.ToString(), error);
                }
            }
            catch
            {
            }
        }


        public static Exception GetInnerException(Exception ex)
        {
            if (ex == null)
            {
                return null;
            }
            if (ex.InnerException == null)
            {
                return ex;
            }
            return GetInnerException(ex.InnerException);
        }



        public static string GetExceptionMessage(Exception ex)
        {
            if (ex == null)
            {
                return string.Empty;
            }
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("\r\n--------- Exception Information [Begin] {0} ---------------\r\n", DateTime.Now.ToString());
            sb.AppendFormat("ExceptionType : {0}\r\n", ex.GetType().FullName);
            sb.AppendFormat("Message : {0}\r\n", ex.Message);
            sb.AppendFormat("StackTrace :\r\n{0}\r\n\r\n", ex.StackTrace);
            if (ex.InnerException != null)
            {
                AppendInnerExceptionInfo(sb, ex.InnerException, "");
            }

            sb.AppendFormat("\r\n--------- Exception Information [End] ----------------------\r\n", DateTime.Now.ToString());
            return sb.ToString();
        }

        private static void AppendInnerExceptionInfo(StringBuilder sb, Exception ex, string prefix)
        {
            sb.AppendFormat("{0}InnerException :\r\n", prefix);
            prefix = prefix + "  ";
            sb.AppendFormat("{0}ExceptionType : {1}\r\n", prefix, ex.GetType().FullName);
            sb.AppendFormat("{0}Message : {1}\r\n", prefix, ex.Message);
            sb.AppendFormat("{0}StackTrace :\r\n{1}\r\n\r\n", prefix, ex.StackTrace);
            if (ex.InnerException != null)
            {
                AppendInnerExceptionInfo(sb, ex.InnerException, prefix);
            }
        }
        
    }
}
