﻿using System.Linq;
using System.Reflection;

namespace Newegg.EbayPMS.Service.Common
{
    public static class ReflectionHelper
    { 
        public static object GetValueOrDefault(object obj, string propertyName)
        {
            object value = null;
            if (!TryGetPropertyValue(obj, propertyName, out value))
            {
                if (!TryGetFiledValue(obj, propertyName, out value))
                {
                    return null;
                }
            }
            return value;
        }

        public static bool TryGetPropertyValue(object obj, string propertyName, out object value)
        {
            if (obj == null)
            {
                value = null;
                return true;
            }

            propertyName.AssertIsNotEmpty();
            PropertyInfo[] propertys = obj.GetType().GetProperties();
            if (!propertys.IsNullOrEmpty())
            {
                var property = propertys.ToList < PropertyInfo>().Find(p => p.Name == propertyName);
                if (property != null)
                {
                    if (property.CanRead)
                    {
                        value = property.GetValue(obj, null);
                        return true;
                    }
                }
            }
            value = null;
            return true;
        }

        public static bool TryGetFiledValue(object obj, string fieldName, out object value)
        {
            if (obj == null)
            {
                value = null;
                return true;
            }
            fieldName.AssertIsNotEmpty();
            FieldInfo[] fields = obj.GetType().GetFields();
            if (!fields.IsNullOrEmpty())
            {
                var field = fields.ToList<FieldInfo>().Find(p => p.Name == fieldName);
                if (field != null)
                {
                    value = field.GetValue(obj);
                    return true;
                }
            }
            value = null;
            return true;
        }
    }
}
