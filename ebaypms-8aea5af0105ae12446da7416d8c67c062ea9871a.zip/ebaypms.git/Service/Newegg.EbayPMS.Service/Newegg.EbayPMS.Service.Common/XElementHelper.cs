﻿using System;
using System.Xml.Linq;

namespace Newegg.EbayPMS.Service.Common
{
    public static class XElementHelper
    {
        public static string GetAttributeValue(this XElement element, XName name, bool isRequire, string defaultValue)
        {
            if (element == null)
            {
                if (isRequire)
                {
                    throw new ArgumentNullException("element");
                }
                return defaultValue;
            }
            XAttribute attribute = element.Attribute(name);
            if (attribute == null)
            {
                if (isRequire)
                {
                    throw new Exception(string.Format("Cannot find attribute[{0}].", name));
                }
                return defaultValue;
            }
            return attribute.Value;
        }
        public static string GetAttributeValue(this XElement element, XName name)
        {
            return GetAttributeValue(element, name, false);
        }
        public static string GetAttributeValue(this XElement element, XName name, bool isRequire)
        {
            return GetAttributeValue(element, name, isRequire, string.Empty);
        }

        public static string GetValue(this XElement element, string defaultValue="")
        {
            if (element == null)
            {
                return defaultValue;
            }
            return element.Value.ToString();
        }

    }
}
