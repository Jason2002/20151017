﻿using System;

namespace Newegg.EbayPMS.Service.Common
{
    [Serializable]
    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Enum
        , AllowMultiple = false)]
    public class EnumCodeAttribute : Attribute
    {
        public EnumCodeAttribute(string code, string displayName)
        {
            Code = code;
            DispalyName = displayName;
        }

        public EnumCodeAttribute(string code)
            : this(code, string.Empty)
        {
        }

        public string Code { get; set; }
        public string DispalyName { get; set; }
    }
}
