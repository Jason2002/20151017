USE ccms3
GO
/*================================================================================  
Server:    s8sql01 
DataBase:  ccms3
Author:    denny
Object:    Ebay_ItemAttachment
Version:   1.0  
Date:      ??/??/????
Content:   ?
----------------------------------------------------------------------------------  
Modified history:      
      
Date        Modified by    VER    Description      
------------------------------------------------------------  
??/??/????  ??			   1.0    Create.  
================================================================================*/  



CREATE Table [dbo].Ebay_ItemAttachment
(
		RowId	INT IDENTITY(1,1)	NOT NULL
	,	OrderNumber	varchar(50) NOT NULL
	,	OrderType	varchar(10) NOT NULL
	,	InUser	varchar(15) NOT NULL
	,	InDate	DateTime NOT NULL
	,	LastEditUser	varchar(15) NULL
	,	LastEditDate	DateTime NULL
	,   AttachmentType varchar(20) NULL
	,	URL VARCHAR(1000) NOT NULL
	,   AttachmentName NVARCHAR(2000)
	,	CONSTRAINT [PK_Ebay_ItemAttachment] PRIMARY KEY CLUSTERED 
		(
			RowId ASC
		)
) ON [PRIMARY]
GO

--How to create standard nonclustered index 
--������ͨ����
CREATE NONCLUSTERED INDEX IX_Ebay_ItemAttachment_OrderNumber ON dbo.Ebay_ItemAttachment 
(
	OrderNumber
)WITH (FILLFACTOR = 90)
Go
