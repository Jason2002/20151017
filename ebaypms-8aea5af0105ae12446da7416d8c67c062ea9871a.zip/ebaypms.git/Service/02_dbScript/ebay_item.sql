USE ccms3
GO
/*================================================================================  
Server:    s8sql01 
DataBase:  ccms3
Author:    denny.l.yu
Object:    
Version:   1.0  
Date:      ??/??/????
Content:   ?
----------------------------------------------------------------------------------  
Modified history:      
      
Date        Modified by    VER    Description      
------------------------------------------------------------  
??/??/????  ??			   1.0    Create.  
================================================================================*/  

CREATE Table [dbo].Ebay_Item
(	
		RowId		INT IDENTITY(1,1)	NOT NULL
	,	ControlCode	 varchar(50)	not  null
	,	InDate	DateTime	not  null
	,	InUser	varchar(15)	not  null
	,	InUserName	nvarchar(50)	null
	,	WarehouseNumber	varchar(20)	not  null
	,	ItemCode	varchar(40)	not  null
	,	[Description]	nvarchar(200)	not  null
	,	EbayCode	varchar(50)	null
	,	OriginPOCost	decimal(10,2)	not  null
	,	Category	Nvarchar(200)	not  null
	,	SerialNumber	varchar(40)	null
	,	[Status]	varchar(20)	not  null
	,	RMAPalletNumber	varchar(60)	null
	,	Location	varchar(50)	null
	,	NotTested	int	null
	,	OtherParts	nvarchar(4000)	null
	,	DamageDescription	nvarchar(4000)	null
	,	TestingNote	nvarchar(4000)	null
	,	LastEditUser	varchar(15)	null
	,	LastEditUserName	nvarchar(50)	null
	,	LastEditDate	DateTime	null
	,	ListedTimes	int
	,	SubmitDate	DateTime
	,	SubmitUser	varchar(15)
	,	SubmitUserName	nvarchar(50)
	,	Condition varchar(20)
	,   CONSTRAINT [PK_Ebay_Item] PRIMARY KEY CLUSTERED --Also can be 'PK_Table_TransactionNumber'
	(
		RowId ASC
	)
) ON [PRIMARY]
GO




CREATE NONCLUSTERED INDEX IX_Ebay_Item_ControlCode ON dbo.Ebay_Item 
(
	ControlCode
)WITH (FILLFACTOR = 90)
Go

CREATE NONCLUSTERED INDEX IX_Ebay_Item_InDate ON dbo.Ebay_Item 
(
	InDate
)WITH (FILLFACTOR = 90)
Go

CREATE NONCLUSTERED INDEX IX_Ebay_Item_ItemCode ON dbo.Ebay_Item 
(
	ItemCode
)WITH (FILLFACTOR = 90)
Go

CREATE NONCLUSTERED INDEX IX_Ebay_Item_SerialNumber ON dbo.Ebay_Item 
(
	SerialNumber
)WITH (FILLFACTOR = 90)
Go

CREATE NONCLUSTERED INDEX IX_Ebay_Item_EbayCode ON dbo.Ebay_Item 
(
	EbayCode
)WITH (FILLFACTOR = 90)
Go