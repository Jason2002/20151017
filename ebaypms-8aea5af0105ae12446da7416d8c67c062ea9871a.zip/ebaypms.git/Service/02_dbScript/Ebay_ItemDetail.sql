USE ccms3
GO
/*================================================================================  
Server:    s8sql01  
DataBase:  ccms3
Author:    denny
Object:    Ebay_ItemDetail
Version:   1.0  
Date:      ??/??/????
Content:   ?
----------------------------------------------------------------------------------  
Modified history:      
      
Date        Modified by    VER    Description      
------------------------------------------------------------  
??/??/????  ??			   1.0    Create.  
================================================================================*/  


CREATE Table [dbo].Ebay_ItemDetail
(
	ROWID		INT IDENTITY(1,1)	NOT NULL
,	ControlCode	varchar(50)
,	FieldName	varchar(200)
,	FieldValue	varchar(200)
,	InUser	varchar(15)
,	InDate	DateTime
,	LastEditUser	varchar(15)
,	LastEditDate	DateTime
,	DisplayOrder	int
,	FieldType 	VARCHAR(20)
,	CONSTRAINT [PK_Ebay_ItemDetail] PRIMARY KEY CLUSTERED 
	(
		ROWID ASC
	)
) ON [PRIMARY]
GO



CREATE NONCLUSTERED INDEX IX_Ebay_ItemDetail_ControlCode ON dbo.Ebay_ItemDetail 
(
	ControlCode
)WITH (FILLFACTOR = 90)
Go


