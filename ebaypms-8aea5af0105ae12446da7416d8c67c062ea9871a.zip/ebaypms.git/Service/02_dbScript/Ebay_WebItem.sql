USE CCMS3
GO
/*================================================================================  
Server:    s8sql01  
DataBase:  ccms3
Author:    denny
Object:    DBO.Ebay_WebItem
Version:   1.0  
Date:      ??/??/????
Content:   ?
----------------------------------------------------------------------------------  
Modified history:      
      
Date        Modified by    VER    Description      
------------------------------------------------------------  
??/??/????  ??			   1.0    Create.  
================================================================================*/  

CREATE Table DBO.Ebay_WebItem
(
		RowId	INT IDENTITY(1,1)	NOT NULL
	,	EbayCode	varchar(50) NOT NULL
	,	ControlCode	varchar(50)
	,	EbayTitle	nvarchar(1000) 
	,	FixedPrice	decimal(10,2) 
	,	StartingPrice	decimal(10,2)
	,	ShippingFee	decimal(10,2)
	,	TotalPrice	decimal(10,2)
	,	TrackingNumber	varchar(50)
	,	InUser	varchar(15) NOT NULL
	,	InDate	DateTime NOT NULL
	,	LastEditUser	varchar(15)
	,	LastEditDate	DateTime
	,	SKU	VARCHAR(200)
	,	ShippingMethod	varchar(100)
	,	StartListDate	DateTime
	,	EndListDate	DateTime
	,	PaidDate	DateTime
	,	ShippedDate	DateTime
	,	ReceiveDate 	DateTime
	,	ListingStatus	varchar(30)	
	,	CONSTRAINT [PK_Ebay_WebItem] PRIMARY KEY CLUSTERED 
		(
			RowId ASC
		)
) ON [PRIMARY]
GO


CREATE NONCLUSTERED INDEX IX_Ebay_WebItem_EbayCode ON DBO.Ebay_WebItem 
(
	EbayCode
)WITH (FILLFACTOR = 90)
Go

CREATE NONCLUSTERED INDEX IX_Ebay_WebItem_TrackingNumber ON DBO.Ebay_WebItem 
(
	TrackingNumber
)WITH (FILLFACTOR = 90)
Go

CREATE NONCLUSTERED INDEX IX_Ebay_WebItem_ControlCode ON DBO.Ebay_WebItem 
(
	ControlCode
)WITH (FILLFACTOR = 90)
Go
