/**
 * Created by rc59 on 8/22/2015.
 */
var WHTab = angular.module("ebaypms-wh", ['ngRoute']);
WHTab.controller("ebaypms-ItemDetail-Ctrl",["$scope","$http","ebayRestClient","messager",function($scope,$http,ebayRestClient,messager){
    $scope.getDataDetail= function (ControlCode) {
        if(ControlCode!=undefined){
            if(ControlCode!=''){
                ebayRestClient.rest("/item/"+ControlCode+"?random="+Math.random()).get(function (data) {

                    $scope.DataDetail = data;
                    console.log(data);
                    //做一些格式化设置
                    $scope.DataDetail.DamagedCondition=[];
                    $scope.DataDetail.PartsIncluded=[];
                    for(var i=0;i<$scope.DataDetail.ItemOptionList.length;i++){
                        if($scope.DataDetail.ItemOptionList[i].FieldType==""){
                        $scope.DataDetail.DamagedCondition.push(
                            {"key":$scope.DataDetail.ItemOptionList[i].FieldName,"value":($scope.DataDetail.ItemOptionList[i].FieldValue=="Y"?true:false)}
                        );
                        }

                        if($scope.DataDetail.ItemOptionList[i].FieldType=="Parts"){
                        $scope.DataDetail.PartsIncluded.push(
                            {"key":$scope.DataDetail.ItemOptionList[i].FieldName,"value":($scope.DataDetail.ItemOptionList[i].FieldValue=="Y"?true:false)}
                        );
                        }
                    }
                    $scope.DataDetail.NotTested=$scope.DataDetail.NotTested==1?true:false;


                });
            }
            else{
                $scope.DataDetail={};
                $scope.canDownloadPicture=false;
            }
        }
    };

    $scope.download=function(){
        var content=$(".download");
        if(content.length==0){
            messager.error("Please choose one picture at least.")
        }
        for(var i=0;i<content.length;i++){
            content[i].click();
        }
    }

//------------------------------------------以下用来监控数据变化---------------------------------------------------

    //此方法用来获取QueryTab通过传过来的数据，再通过watch这个变量，就可知道ControlCode有无变化，变化了就刷新数据
    $scope.$on("ControlCodeChangeForChildScope",
        function (event, msg) {
            $scope.ControlCode = msg;
        });
    //当QueryTab中传过来的ControlCode改变时，获取一遍数据，如果不监听ControlCode，则拿不到数据
    $scope.$watch((function () {
        return $scope.ControlCode;
    }),function(val){
        if(val!=undefined){
            $scope.isSelectAll=false;
            $scope.getDataDetail(val);
        }
    });

    //此方法用来获取eBayTab传过来的数据，再通过watch这个变量，就可知道eBayTab页面有无数据更新，更新了就刷新数据
    $scope.$on("DataChangeForChildScope",
        function (event, msg) {
            $scope.isEBayTabChangeData = msg.changed;
            console.log(msg);
        });
    $scope.$watch((function () {
        return $scope.isEBayTabChangeData;
    }),function(val){
        if(val!=undefined){
            $scope.getDataDetail($scope.DataDetail.ControlCode);
        }
    });

    //当获取的数据DataList改变时，保证http.get数据完成后，做一些格式化设置和一些控件的是否可操作赋值
    $scope.$watch((function () {
        return $scope.DataDetail;
    }),function(val){
        if(val!=undefined){
            var pictureCanDelete=val.PictureList;
            if (pictureCanDelete==undefined){
                return;
            }
            if(pictureCanDelete.length==0){
                $scope.canDownloadPicture=false;
            }
            else{
                $scope.canDownloadPicture=true;
            }
        }
    });
}]);


//window.onload=function(){
//    for(var i=0;i<document.getElementsByClassName("selectPic").length;i++){
//        if(document.getElementsByClassName("selectPic")[i].checked==false){
//            document.getElementsByClassName("selectPic")[i].click();
//        }
//    }
//}

