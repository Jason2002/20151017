/**
 * Created by rc59 on 8/22/2015.
 */
var eBayTab = angular.module("ebaypms-eBayTab", ['ngRoute']);
eBayTab.controller("ebaypms-eBayTab-Ctrl",
    ["$scope","$http","authorize","ebayRestClient","messager", function($scope,$http,authorize,ebayRestClient,messager){

    $scope.getDataDetail= function (ControlCode) {
        if(ControlCode!=undefined){
            if(ControlCode!=''){
                ebayRestClient.rest("/item/"+ControlCode+"?random="+Math.random()).get(function (data) {
                    $scope.bindDetail(data);
                });
            }
            else{
                $scope.DataDetail={};
            }
        }
    };
    $scope.bindDetail = function (data) {
        $scope.DataDetail = data;
        if (data.Status == "Ready" || data.Status == "Listed" || data.Status == "Ended") {
            $scope.cannotItemEdit = false;
        }
        else {
            $scope.cannotItemEdit = true;
        }
        console.log(data);
    };
    $scope.getEBayData=function(eBayCode){
        if($scope.DataDetail.EbayCode!="" && $scope.DataDetail.ControlCode!=undefined){
            ebayRestClient.rest("/EbayCode?EbayCode="+eBayCode+"&random="+Math.random()).get(function (data) {
                console.log(data);
                $scope.DataDetail.Status=data.Status;
                $scope.DataDetail.EbayTitle=data.EbayTitle;
                $scope.DataDetail.FixedPrice=data.FixedPrice;
                $scope.DataDetail.StartingPrice=data.StartingPrice;
                $scope.DataDetail.ShippingFee=data.ShippingFee;
                $scope.DataDetail.TrackingNumber=data.TrackingNumber;
            });
        }
    };
    $scope.enter = function ($event,EbayCode) {
        if ($event.which == 13) {
            $scope.getEBayData(EbayCode);
        }
    };
    $scope.save=function(){
        console.log($scope.DataDetail.EbayCode);
        console.log($scope.DataDetail.EbayCode);
        if($scope.DataDetail.ControlCode!=undefined){
            ebayRestClient.rest("/item/"+$scope.DataDetail.ControlCode+'/EbayCode').put(
                {
                    "ControlCode": $scope.DataDetail.ControlCode,
                    "EbayCode": $scope.DataDetail.EbayCode,
                    "LastEditUser": authorize.accountInfo.UserID
                }
            ).$promise.then(function(data) {
                    //$scope.getDataDetail($scope.DataDetail.ControlCode);
                //告诉其他controller有数据更新
                $scope.bindDetail(data);
                $scope.isChanged = !$scope.isChanged;
                $scope.change({ "changed": $scope.isChanged, "status": "--ALL--" });
                messager.success("Save successfully.");
            });
        }
    };




//-----------------------------------------以下为监控数据变化------------------------------------------------

    //change方法用来告诉父controller此controller中有数据更新，再由父controller告诉其他子controller要刷新数据
    $scope.change = function (changed) {
        $scope.$emit("DataChange", changed);
    };
    //没更新一次数据，就让isChanged取反，在父controller中监听这个传过去的量，变了就提醒其他子controller刷新数据
    $scope.isChanged=false;//初始化

    //此方法用来获取QueryTab通过ebaypms-Ctrl传过来的数据，再通过watch这个变量，就可知道ControlCode有无变化，变化了就刷新数据
    $scope.$on("ControlCodeChangeForChildScope",
        function (event, msg) {
            $scope.ControlCode = msg;
        });
    //当QueryTab中传过来的ItemNumber改变时，获取一遍数据，如果不监听ItemNumber，则拿不到数据
    $scope.$watch((function () {
        return $scope.ControlCode;
    }),function(val){
        if(val!=undefined){
            $scope.getDataDetail(val);
        }
    });
}]);
