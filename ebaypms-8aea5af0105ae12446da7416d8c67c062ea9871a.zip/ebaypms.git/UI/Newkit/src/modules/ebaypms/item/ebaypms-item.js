﻿var mainModule = angular.module('ebaypms-item', ['ebaypms-QueryTab', 'ebaypms-eBayTab', 'ebaypms-wh', 'ngRoute']);
mainModule.config(["$routeProvider", function($routeProvider) {
    $routeProvider
        .when("/ebaypms/item", {
            templateUrl: "/modules/ebaypms/item/itemmaster.tpl.html",
            controller: 'ebaypms-Ctrl',
            resolve: {
                framework: [
                    "globalConfig", function(globalConfig) {
                        globalConfig.load("Newkit");
                    }
                ]
            }
        });
}]);
mainModule.controller("ebaypms-Ctrl",["$scope","$http","ebayConfig","ebayRestClient",function($scope,$http,ebayConfig,ebayRestClient){
    ebayConfig.load().then(
        function() {
            ebayRestClient.rest("/config").get(function (data) {
                //Category、Status筛选条件都加上ALL选项
                $scope.Category = ['--ALL--'].concat(data.CategoryList);
                $scope.Status = ['--ALL--'].concat(data.StatusList);
            }, function (error) {
                console.log(error);
            });
            $scope.FilterCondition=['Item#','C#','Serial#','Tracking#','eBay Title','eBay#'];
            $scope.TabItems=[{
                title: "Query",
                contentURL: "/modules/ebaypms/item/querytab.tpl.html",
                active: true
            }, {
                title: "Item Detail",
                active: false,
                contentURL: "/modules/ebaypms/item/itemdetailtab.tpl.html"
            },{
                title: "eBay",
                active: false,
                contentURL: "/modules/ebaypms/item/ebaytab.tpl.html"
            }];

            $scope.changeTab = function (tabName, ControlCode) {
                switch (tabName) {
                    case "Query":
                        $scope.TabItems[0].active = true;
                        break;
                    case "Item Detail":
                        $scope.ControlCode=ControlCode;
                        $scope.TabItems[1].active = true;
                        break;
                    case "eBay":
                        $scope.ControlCode=ControlCode;
                        $scope.TabItems[2].active = true;
                        setTimeout(function () {
                            $('#eBayTab_eBayCode').focus();
                        }, 50);
                        break;
                }
            };

            //此方法用来拿到ItemDetailTab中传过来的数据，再把该数据传递给QueryTab和eBayTab
            $scope.$on("DataChange",
                function (event, msg) {
                    $scope.$broadcast("DataChangeForChildScope", msg);
                    //$scope.$broadcast("DataChangeForItemDetail", msg);
                });

            $scope.$on("ControlCodeChange",
                function (event, msg) {
                    $scope.$broadcast("ControlCodeChangeForChildScope", msg);
                });
        }
    );

}]);



