﻿/**
 * Created by rc59 on 8/21/2015.
 */
var QueryTab = angular.module("ebaypms-QueryTab", ['ngRoute']);
QueryTab.controller("ebaypms-Query-Ctrl",["$scope","$http","ebayRestClient","messager",function($scope,$http,ebayRestClient,messager){
    //查询条件初始化
    $scope.queryParam={
        "category":"--ALL--",
        "status":"--ALL--",
        "filterKey":"Item#",
        "filterValue":"",
        "dateFrom":"",
        "dateTo":"",
        "createUser":""
    };

    $scope.getData=function(){
        var restUrl="?random="+Math.random();
        //当没有查询条件时
        if(true
        && $scope.queryParam.category=="--ALL--" && $scope.queryParam.status=="--ALL--"
        && $scope.queryParam.filterValue=="" && $scope.queryParam.dateFrom==""
        && $scope.queryParam.dateTo=="" && $scope.queryParam.createUser==""
        ){}
        //当有查询条件时
        else{
            if($scope.queryParam.category!="--ALL--"){
                //把所有“ ”替换成“%20”----在url中“%20”表示空格
                var category=$scope.queryParam.category.replace(new RegExp(" ","gm"),"%20");
                //把所有“&”替换成“%26”----在url中“%26”表示“&”
                category=category.replace(new RegExp("&","gm"),"%26");
                restUrl+="&category="+category;
            }
            if($scope.queryParam.status!="--ALL--"){
                restUrl+="&status="+$scope.queryParam.status;
            }
            if($scope.canDateUse){
                if($scope.queryParam.dateFrom!=""){
                    restUrl+="&fromdate="+correctDate($scope.queryParam.dateFrom);
                }
                if($scope.queryParam.dateTo!=""){
                    restUrl+="&todate="+correctDate(DatePlusOne($scope.queryParam.dateTo));
                }
            }
            if($scope.queryParam.createUser!=""){
                restUrl+="&inusername="+$scope.queryParam.createUser;
            }
            try{
                switch ($scope.queryParam.filterKey){
                    case "Item#":
                        if($scope.queryParam.filterValue!=""){
                            restUrl+="&itemCode="+$scope.queryParam.filterValue;
                        }
                        break;
                    case "C#":
                        if($scope.queryParam.filterValue!=""){
                            restUrl="?controlCode="+$scope.queryParam.filterValue;
                        }
                        break;
                    case "Serial#":
                        if($scope.queryParam.filterValue!=""){
                            restUrl+="&serialNumber="+$scope.queryParam.filterValue;
                        }
                        break;
                    case "Tracking#":
                        if($scope.queryParam.filterValue!=""){
                            restUrl+="&TrackingNumber="+$scope.queryParam.filterValue;
                        }
                        break;
                    case "eBay Title":
                        if($scope.queryParam.filterValue!=""){
                            restUrl+="&ebayTitle="+$scope.queryParam.filterValue;
                        }
                        break;
                    case "eBay#":
                        if($scope.queryParam.filterValue!=""){
                            restUrl="?ebayCode="+$scope.queryParam.filterValue;
                        }
                        break;
                }
            }
            catch (e){
                console.log(e);
            }
        }

        ebayRestClient.rest("/item"+restUrl).query(function (data) {
            $scope.DataList = data;
            if(data.length==0){
                messager.error("No Data Found.");
                //$('#grid').css('background-image','url(/modules/ebaypms/imgs/noData.jpg)');
                //$('#grid').css('background-repeat','no-repeat');
                //$('#grid').css('background-position','center');
            }
            //else{
            //    $('#grid').css('background-image','');
            //}
        }, function (error) {
            $scope.DataList = null;
        });
    };

    $scope.search=function(){
        var date=new RegExp("(^$)|(^(1[0-2]|[1-9]|0[1-9])/(3[0-1]|2[0-9]|1[0-9]|[1-9]|0[1-9])/([0-9]{4,})$)");
        if((!date.test($scope.queryParam.dateFrom) || !date.test($scope.queryParam.dateTo))){
            if(!date.test($scope.queryParam.dateFrom)){
                $scope.isDateFromWrong=true;
            }
            else{
                $scope.isDateFromWrong=false;
            }
            if(!date.test($scope.queryParam.dateTo)){
                $scope.isDateToWrong=true;
            }
            else{
                $scope.isDateFromTo=false;
            }
            return;
        }
        else if ($scope.queryParam.dateFrom!="" && $scope.queryParam.dateTo!="" && $scope.canDateUse
            && strToDate(correctDate($scope.queryParam.dateFrom))>strToDate(correctDate($scope.queryParam.dateTo))){
            messager.error("From Date cannot be greater than To Date.");
            return;
        }
        $scope.isDateFromWrong=false;
        $scope.isDateToWrong=false;
        console.log($scope.queryParam);
        $scope.getData();
        $scope.change("");
    };

    $scope.enter = function ($event) {
        if ($event.which == 13) {
            $scope.search();
        }
    };

    //$scope.canDateUseChange=function (value){
    //    if(value){
    //        document.getElementById("datepicker1").disabled=true;
    //    }
    //}

    $scope.DataList = [];
    $scope.canDateUse=false;
    $scope.isDateFromWrong=false;
    $scope.isDateToWrong=false;


//-----------------------------------------------以下用来监控数据变化---------------------------------------------

    //change方法用来告诉父controller此controller中有数据更新，再由父controller告诉其他子controller要刷新数据
    $scope.change = function (ControlCode) {
        $scope.$emit("ControlCodeChange", ControlCode);
    };

    //此方法用来获取eBayTab传过来的数据，再通过watch这个变量，就可知道eBayTab页面有无数据更新，更新了就刷新数据
    $scope.$on("DataChangeForChildScope",
        function (event, msg) {
            $scope.isEBayTabChangeData = msg.changed;
            $scope.queryParam.status=msg.status;
            console.log(msg);
        });
    $scope.$watch((function () {
        return $scope.isEBayTabChangeData;
    }),function(val){
        if(val!=undefined){
            $scope.getData();
        }
    });

    //监听DataList，当DataList变化后更新grid。作用为:保证TotalList数据更新时 以及 查询条件变化时，更新grid
    $scope.$watch((function () {
        return $scope.DataList;
    }),function(val){
        if (val!=undefined) {
            var data = {data: val, total: val.length};
            $("#grid").kendoGrid({
                dataSource: {
                    data: data,
                    schema: {
                        data: "data",
                        total: "total"
                    },
                    pageSize: 100,
                    page: 1
                },
                dataBound: function () {
                    $(".idColumn").click(function () {
                        var caseid = $(this).attr("id");
                        $scope.change(caseid);
                        $scope.changeTab("Item Detail");
                        $scope.$apply();
                    });
                },
                height: 550,
                sortable: true,
                pageable: {
                    pageSizes: [20, 50, 100],
                    previousNext: false,
                    buttonCount: 5
                },
                filterable: true,
                columns: [{
                    template: '<a id="#=ControlCode#" class="idColumn" href="javascript:void(0)">#=ControlCode#</a>',
                    field: "ControlCode",
                    title: "C#",
                    width: 140
                }, {
                    field: "ItemCode",
                    title: "Item#",
                    width: 100
                }, {
                    field: "Description",
                    title: "Description"
                }, {
                    field: "Status",
                    title: "Status",
                    width: 90
                }, {
                    field: "SerialNumber",
                    title: "SN",
                    width: 120
                }, {
                    field: "EbayCode",
                    title: "eBay#",
                    width: 150
                }, {
                    field: "EbayTitle",
                    title: "eBay Title"
                }]
            });
        }
    });
}]);