﻿/**
 * Created by rc59 on 8/20/2015.
 */
angular.module('ebaypms', ['ebaypms-item','ngResource', 'ngRoute'])
.factory('ebayRestClient', ['$resource','ebayConfig',
    function($resource,ebayConfig,globalConfig) {
        return {
            rest: function(restUrl) {
                var baseUrl=ebayConfig.getURL();
                var token = ebayConfig.getAPIToken();
                return $resource("" + baseUrl + restUrl, {}, {
                    get: {
                        method: "GET",
                        headers: {
                            "Authorization": "Bearer " + token.access_token || ''
                        },
                        timeout: 60000
                    },
                    query: {
                        method: "GET",
                        headers: {
                            "Authorization": "Bearer " + token.access_token || ''
                        },
                        timeout: 60000,
                        isArray: true
                    },
                    put: {
                        method: "PUT",
                        headers: {
                            "Authorization": "Bearer " + token.access_token || ''
                        },
                        timeout: 60000
                    },
                    post: {
                        method: "POST",
                        headers: {
                            "Authorization": "Bearer " + token.access_token || ''
                        },
                        timeout: 60000
                    },
                    postList: {
                        method: "POST",
                        headers: {
                            "Authorization": "Bearer " + token.access_token || ''
                        },
                        timeout: 60000,
                        isArray: true
                    },
                    del: {
                        method: "DELETE",
                        headers: {
                            "Authorization": "Bearer " + token.access_token || ''
                        },
                        timeout: 60000
                    }
                });
            }
        }
    }
])

.factory("ebayConfig", ["globalConfig", "authorize", function(globalConfig, authorize) {
    var restAPIURL;
    var restAPPID;
    var restAPIToken;

    return {
        load: function() {
            return globalConfig.load("EbayPMS").then(
                function() {
                    restAPIURL = globalConfig.get("EbayPMS", "RestAPIBaseURL");
                    restAPPID = globalConfig.get("EbayPMS", "RestAPIAppID");
                    return authorize.getOAuthToken(restAPPID).then(function(data) {
                        restAPIToken = data;
                    });
                }
            );
        },
        getURL: function() {
            return restAPIURL;
        },
        getAppID: function() {
            return restAPPID;
        },
        getAPIToken: function() {
            return restAPIToken;
        }
    };
}]);



function canDownloadPicture(){
    if (navigator.appName=="Microsoft Internet Explorer"){
        alert("Your browse can not support picture-download, please use chrome or click right-button to Save Picture As...");
        window.event.returnValue = false;
    }
}


//-------------------------------------以下为日期转换函数---------------------------------------------

//'12/9/2015'这种格式转换为标准日期格式
function strToDate(str)
{
    var arys= new Array();
    arys=str.split('/');
    var newDate=new Date(arys[2],arys[0]-1,arys[1]);
    return newDate;
}
//'2015-09-12'这种格式转换为标准日期格式
function strToDate2(str)
{
    var arys= new Array();
    arys=str.split('-');
    var newDate=new Date(arys[0],arys[1]-1,arys[2]);
    return newDate;
}

//'/Date(1441987200000+0800)/'这种格式转换为’2015-09-12‘
function data_string(str) {
    var d = eval('new ' + str.substr(1, str.length - 2));
    var ar_date = [d.getFullYear(), d.getMonth() + 1, d.getDate()];
    for (var i = 0; i < ar_date.length; i ++) ar_date[i] = dFormat(ar_date[i]);
    return ar_date.join('-');

    function dFormat(i) { return i < 10 ? "0" + i.toString() : i; }
}

//日期加一天，即9/2/2015变为9/3/2015
function DatePlusOne(str) {
    var arys= new Array();
    arys=str.split('/');
    var newDateString=arys[0]+"/"+(arys[1]-0+1)+"/"+arys[2];
    return newDateString;
}

//由于kendo日历控件的自身原因————选了一个时间后，再往输入框里最后输入数字，失去焦点之后这个控件会自动留年份的前四位
function correctDate(str){
    var arys= new Array();
    arys=str.split('/');
    var newDateString=arys[0]+"/"+arys[1]+"/"+arys[2].substring(0,4);
    return newDateString;
}