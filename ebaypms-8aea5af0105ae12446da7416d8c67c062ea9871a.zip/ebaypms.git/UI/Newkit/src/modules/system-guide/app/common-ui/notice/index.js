angular.module('system-guide-common-ui-notice', [])
  .controller('SystemGuideCommonNoticeDemoCtrl', ["$scope", "messager", function ($scope, messager) {
    $scope.regular = function () {
      messager.notice({
        title: 'This is a regular notice!',
        text: 'This will fade out after a certain amount of time. Vivamus eget tincidunt velit. Cum sociis natoque penatibus et <a href="#" class="blue">magnis dis parturient</a> montes, nascetur ridiculus mus.',
        image: '/framework/img/avatar.png',
        sticky: false,
        time: ''
      });
    };

    $scope.sticky = function () {
      messager.notice({
        title: 'This is a sticky notice!',
        text: 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus eget tincidunt velit. Cum sociis natoque penatibus et <a href="#" class="red">magnis dis parturient</a> montes, nascetur ridiculus mus.',
        image: '/framework/img/avatar.png',
        sticky: true,
        time: '',
        class_name: 'gritter-info'
      });
    };

    $scope.withoutimage = function () {
      messager.notice({
        // (string | mandatory) the heading of the notification
        title: 'This is a notice without an image!',
        // (string | mandatory) the text inside the notification
        text: 'This will fade out after a certain amount of time. Vivamus eget tincidunt velit. Cum sociis natoque penatibus et <a href="#" class="orange">magnis dis parturient</a> montes, nascetur ridiculus mus.',
        class_name: 'gritter-success'
      });
    };

    $scope.warring = function () {
      messager.notice({
        title: 'This is a warning notification.',
        text: 'This will fade out after a certain amount of time. Vivamus eget tincidunt velit. Cum sociis natoque penatibus et <a href="#" class="green">magnis dis parturient</a> montes, nascetur ridiculus mus.',
        image: '/framework/img/avatar.png',
        sticky: false,
        class_name: 'gritter-warning'
      });
    };

    $scope.error = function () {
      messager.notice({
        title: 'This is a error notification',
        text: 'Just add a "gritter-light" class_name to your $.gritter.add or globally to $.gritter.options.class_name',
        class_name: 'gritter-error'
      });
    };
  }
  ]);
