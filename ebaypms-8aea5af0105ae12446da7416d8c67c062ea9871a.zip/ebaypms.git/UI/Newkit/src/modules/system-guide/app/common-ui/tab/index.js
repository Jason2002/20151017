angular.module('system-guide-common-ui-tab', [])
    .controller("SystemGuideCommonTabsDemoCtrl", ["$scope", function ($scope) {
        $scope.tabs = [
            {
                title: "Title 1",
                content: "content 1"
            },
            {
                title: "Title 2",
                content: "content 2",
                disabled: true
            }
        ];

        $scope.alertMe = function () {
            setTimeout(function () {
                alert("You've selected the alert tab!");
            });
        };

        $scope.navType = "pills";
    }
    ]);
