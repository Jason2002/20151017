angular.module('system-guide-common-ui-tooltip', [])
  .controller("SystemGuideCommonToolTipDemoCtrl", ["$scope", function ($scope) {

  }
]);
